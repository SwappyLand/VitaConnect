import json
import sys, pathlib
# ensure project root is on sys.path so we can import app.py
sys.path.append(str(pathlib.Path(__file__).resolve().parents[1]))
from app import prescription_to_pdf_bytes

presc = {
    'prescription_id':'PRESC_TEST',
    'created_at':'2026-01-07 10:00:00',
    'doctor_id':'DOC_TEST',
    'patient_id':'PAT_TEST',
    'diagnosis':'Test diagnosis for PDF generation',
    'medicines': json.dumps([
        {'name':'Paracetamol 650mg','no_of_days':5,'times_per_day':2,'before_after':'After meal'},
        {'name':'Vitamin D3','no_of_days':14,'times_per_day':1,'before_after':'Any'}
    ]),
    'notes':'Take medicines after meals if required.'
}

try:
    pdf_bytes = prescription_to_pdf_bytes(presc)
    print('PDF bytes type:', type(pdf_bytes), 'len:', len(pdf_bytes))
    with open('test_presc.pdf', 'wb') as f:
        f.write(pdf_bytes)
    print('Wrote test_presc.pdf')
except Exception as e:
    import traceback
    print('Error generating PDF:', e)
    print(traceback.format_exc())
