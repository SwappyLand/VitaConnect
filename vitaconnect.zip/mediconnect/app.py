"""
VitaConnect - Interactive Healthcare Platform
Complete with prescriptions, medicine marketplace, and animations
"""

import streamlit as st
import pandas as pd
import hashlib
import os
from datetime import datetime, timedelta
import time as time_module
import json
import random

# ============================================================================
# CONFIGURATION
# ============================================================================

CSV_DIR = "data"
PATIENTS_CSV = os.path.join(CSV_DIR, "patients.csv")
DOCTORS_CSV = os.path.join(CSV_DIR, "doctors.csv")
APPOINTMENTS_CSV = os.path.join(CSV_DIR, "appointments.csv")
MEDICINES_CSV = os.path.join(CSV_DIR, "medicines.csv")
PRESCRIPTIONS_CSV = os.path.join(CSV_DIR, "prescriptions.csv")
ORDERS_CSV = os.path.join(CSV_DIR, "orders.csv")

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

# ============================================================================
# ANIMATIONS & STYLES
# ============================================================================

def apply_animations():
    """Apply CSS animations and modern styling"""
    st.markdown("""
    <style>
    /* Global Styles */
    .main {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        animation: gradientShift 10s ease infinite;
    }
    
    @keyframes gradientShift {
        0%, 100% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
    }
    
    /* Card Animations */
    .stButton>button {
        transition: all 0.3s ease;
        border-radius: 10px;
        font-weight: 500;
    }
    
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    
    /* Fade In Animation */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .element-container {
        animation: fadeIn 0.5s ease-out;
    }
    
    /* Pulse Animation */
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    .metric-card {
        animation: pulse 2s ease-in-out infinite;
    }
    
    /* Slide In */
    @keyframes slideIn {
        from { transform: translateX(-100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .sidebar .sidebar-content {
        animation: slideIn 0.5s ease-out;
    }
    
    /* Glow Effect */
    .glow {
        box-shadow: 0 0 18px rgba(102, 126, 234, 0.35);
        border-radius: 10px;
        padding: 16px;
        background: rgba(255,255,255,0.02);
        margin: 6px 0;
    }
    </style>
    """, unsafe_allow_html=True)


# ============================================================================
# DATA INITIALIZATION
# ============================================================================

def init_csv_files():
    """Initialize all CSV files"""
    os.makedirs(CSV_DIR, exist_ok=True)
    
    # Patients
    if not os.path.exists(PATIENTS_CSV):
        pd.DataFrame(columns=['patient_id', 'name', 'email', 'password', 'phone', 'address', 'cart']).to_csv(PATIENTS_CSV, index=False)
    
    # Doctors
    if not os.path.exists(DOCTORS_CSV):
        doctors_data = [
            {'name': 'Dr. Rajesh Sharma', 'email': 'rajeshsharma@gmail.com', 'specialization': 'Cardiologist', 
             'experience': 15, 'hospital': 'Ruby Hall Clinic', 'address': 'Grant Road, Pune', 'phone': '9876543210',
             'degree': 'MBBS, MD (Cardiology)', 'rating': 4.8, 'fee': 800},
            {'name': 'Dr. Priya Deshmukh', 'email': 'priyadeshmukh@gmail.com', 'specialization': 'Dermatologist', 
             'experience': 12, 'hospital': 'Sahyadri Hospital', 'address': 'Nagar Road, Pune', 'phone': '9876543211',
             'degree': 'MBBS, MD (Dermatology)', 'rating': 4.7, 'fee': 700},
            {'name': 'Dr. Amit Kulkarni', 'email': 'amitkulkarni@gmail.com', 'specialization': 'Pediatrician', 
             'experience': 10, 'hospital': 'Surya Hospital', 'address': 'Wakad, Pune', 'phone': '9876543212',
             'degree': 'MBBS, DCH', 'rating': 4.9, 'fee': 600},
            {'name': 'Dr. Sunita Patil', 'email': 'sunitapatil@gmail.com', 'specialization': 'Gynecologist', 
             'experience': 18, 'hospital': 'Deenanath Hospital', 'address': 'Erandwane, Pune', 'phone': '9876543213',
             'degree': 'MBBS, MS', 'rating': 4.9, 'fee': 900},
            {'name': 'Dr. Vikram Joshi', 'email': 'vikramjoshi@gmail.com', 'specialization': 'Orthopedist', 
             'experience': 20, 'hospital': 'Poona Hospital', 'address': 'Camp, Pune', 'phone': '9876543214',
             'degree': 'MBBS, MS (Ortho)', 'rating': 4.8, 'fee': 1000},
        ]
        
        doctors_list = []
        for doc in doctors_data:
            doctors_list.append({
                'doctor_id': f'DOC_{doc["phone"]}',
                'name': doc['name'], 'email': doc['email'], 'password': hash_password('doc123'),
                'phone': doc['phone'], 'city': 'Pune', 'state': 'Maharashtra',
                'degree': doc['degree'], 'specialization': doc['specialization'],
                'experience': str(doc['experience']), 'hospital': doc['hospital'],
                'address': doc['address'], 'rating': doc['rating'], 'fee': doc['fee'],
                'approval_status': 'approved', 'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
        pd.DataFrame(doctors_list).to_csv(DOCTORS_CSV, index=False)
    
    # Medicines
    if not os.path.exists(MEDICINES_CSV):
        medicines = [
            # General Purpose
            {'name': 'Paracetamol 650mg', 'category': 'Pain Relief', 'price': 25, 'stock': 500, 'type': 'General'},
            {'name': 'Ibuprofen 400mg', 'category': 'Pain Relief', 'price': 45, 'stock': 300, 'type': 'General'},
            {'name': 'Cetirizine 10mg', 'category': 'Allergy', 'price': 40, 'stock': 400, 'type': 'General'},
            {'name': 'Vitamin D3', 'category': 'Vitamin', 'price': 150, 'stock': 200, 'type': 'General'},
            {'name': 'Vitamin B12', 'category': 'Vitamin', 'price': 120, 'stock': 250, 'type': 'General'},
            {'name': 'Multivitamin', 'category': 'Vitamin', 'price': 200, 'stock': 180, 'type': 'General'},
            {'name': 'Omeprazole 20mg', 'category': 'Acidity', 'price': 80, 'stock': 350, 'type': 'General'},
            {'name': 'Pantoprazole 40mg', 'category': 'Acidity', 'price': 95, 'stock': 300, 'type': 'General'},
            {'name': 'Cough Syrup', 'category': 'Cough', 'price': 120, 'stock': 150, 'type': 'General'},
            {'name': 'Amoxicillin 500mg', 'category': 'Antibiotic', 'price': 150, 'stock': 200, 'type': 'General'},
            
            # Cardiology
            {'name': 'Aspirin 75mg', 'category': 'Cardiology', 'price': 50, 'stock': 400, 'type': 'Specialized'},
            {'name': 'Atorvastatin 10mg', 'category': 'Cardiology', 'price': 180, 'stock': 250, 'type': 'Specialized'},
            {'name': 'Metoprolol 50mg', 'category': 'Cardiology', 'price': 120, 'stock': 300, 'type': 'Specialized'},
            
            # Dermatology
            {'name': 'Clindamycin Gel', 'category': 'Dermatology', 'price': 250, 'stock': 100, 'type': 'Specialized'},
            {'name': 'Tretinoin Cream', 'category': 'Dermatology', 'price': 300, 'stock': 80, 'type': 'Specialized'},
            {'name': 'Benzoyl Peroxide', 'category': 'Dermatology', 'price': 180, 'stock': 120, 'type': 'Specialized'},
            
            # Pediatrics
            {'name': 'Calpol Syrup', 'category': 'Pediatrics', 'price': 90, 'stock': 200, 'type': 'Specialized'},
            {'name': 'Zinc Drops', 'category': 'Pediatrics', 'price': 110, 'stock': 150, 'type': 'Specialized'},
            
            # Gynecology
            {'name': 'Folic Acid', 'category': 'Gynecology', 'price': 60, 'stock': 300, 'type': 'Specialized'},
            {'name': 'Iron Tablets', 'category': 'Gynecology', 'price': 80, 'stock': 250, 'type': 'Specialized'},
            
            # Orthopedics
            {'name': 'Calcium Tablets', 'category': 'Orthopedics', 'price': 100, 'stock': 300, 'type': 'Specialized'},
            {'name': 'Glucosamine', 'category': 'Orthopedics', 'price': 350, 'stock': 120, 'type': 'Specialized'},
            {'name': 'Pain Relief Spray', 'category': 'Orthopedics', 'price': 200, 'stock': 150, 'type': 'Specialized'},
        ]
        
        med_list = []
        for med in medicines:
            med_list.append({
                'medicine_id': f'MED_{len(med_list)+1:03d}',
                'name': med['name'],
                'category': med['category'],
                'price': med['price'],
                'stock': med['stock'],
                'type': med['type'],
                'manufacturer': random.choice(['Cipla', 'Sun Pharma', 'Dr Reddy', 'Lupin', 'Mankind'])
            })
        pd.DataFrame(med_list).to_csv(MEDICINES_CSV, index=False)
    
    # Appointments
    if not os.path.exists(APPOINTMENTS_CSV):
        pd.DataFrame(columns=[
            'appointment_id', 'doctor_id', 'patient_id', 'doctor_name', 'patient_name',
            'date', 'time', 'status', 'prescription_id', 'symptoms', 'mode', 'created_at'
        ]).to_csv(APPOINTMENTS_CSV, index=False)
    
    # Prescriptions
    if not os.path.exists(PRESCRIPTIONS_CSV):
        pd.DataFrame(columns=[
            'prescription_id', 'appointment_id', 'patient_id', 'doctor_id',
            'medicines', 'diagnosis', 'notes', 'created_at'
        ]).to_csv(PRESCRIPTIONS_CSV, index=False)
    
    # Orders
    if not os.path.exists(ORDERS_CSV):
        pd.DataFrame(columns=[
            'order_id', 'patient_id', 'prescription_id', 'medicines',
            'total_amount', 'delivery_address', 'status', 'created_at'
        ]).to_csv(ORDERS_CSV, index=False)

    # Normalize existing CSVs to ensure compatibility with older files
    try:
        patients_df = load_csv(PATIENTS_CSV)
        patients_df, changed = ensure_columns(patients_df, {
            'patient_id': '', 'name': '', 'email': '', 'password': '', 'phone': '', 'address': '', 'cart': json.dumps([])
        })
        if changed:
            save_csv(patients_df, PATIENTS_CSV)
    except Exception:
        pass

    try:
        doctors_df = load_csv(DOCTORS_CSV)
        doctors_df, changed = ensure_columns(doctors_df, {
            'doctor_id': '', 'name': '', 'email': '', 'password': '', 'phone': '', 'city': '', 'state': '', 'degree': '', 'specialization': '', 'experience': '0', 'hospital': '', 'address': '', 'clinic_address': '', 'rating': 0.0, 'fee': 0, 'approval_status': 'pending', 'created_at': ''
        })
        if changed:
            save_csv(doctors_df, DOCTORS_CSV)
    except Exception:
        pass

    try:
        meds_df = load_csv(MEDICINES_CSV)
        meds_df, changed = ensure_columns(meds_df, {
            'medicine_id': '', 'name': '', 'category': '', 'price': 0.0, 'stock': 0, 'type': 'General', 'manufacturer': ''
        })
        if changed:
            save_csv(meds_df, MEDICINES_CSV)
    except Exception:
        pass

    try:
        appts_df = load_csv(APPOINTMENTS_CSV)
        appts_df, changed = ensure_columns(appts_df, {
            'appointment_id': '', 'doctor_id': '', 'patient_id': '', 'doctor_name': '', 'patient_name': '', 'date': '', 'time': '', 'status': 'confirmed', 'prescription_id': '', 'symptoms': '', 'mode': 'In-person', 'created_at': ''
        })
        if changed:
            save_csv(appts_df, APPOINTMENTS_CSV)
    except Exception:
        pass

    try:
        presc_df = load_csv(PRESCRIPTIONS_CSV)
        presc_df, changed = ensure_columns(presc_df, {
            'prescription_id': '', 'appointment_id': '', 'patient_id': '', 'doctor_id': '', 'medicines': json.dumps([]), 'diagnosis': '', 'notes': '', 'created_at': ''
        })
        if changed:
            save_csv(presc_df, PRESCRIPTIONS_CSV)
    except Exception:
        pass

    try:
        orders_df = load_csv(ORDERS_CSV)
        orders_df, changed = ensure_columns(orders_df, {
            'order_id': '', 'patient_id': '', 'prescription_id': '', 'medicines': json.dumps([]), 'total_amount': 0.0, 'delivery_address': '', 'status': '', 'created_at': ''
        })
        if changed:
            save_csv(orders_df, ORDERS_CSV)
    except Exception:
        pass

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def generate_id(prefix):
    return f"{prefix}_{datetime.now().strftime('%Y%m%d%H%M%S')}"

def load_csv(filepath):
    try:
        df = pd.read_csv(filepath)
        return df
    except:
        return pd.DataFrame()

def save_csv(df, filepath):
    df.to_csv(filepath, index=False)

# --- Patient persistent cart helpers ---
from fpdf import FPDF

def get_patient_cart(patient_id):
    """Return list cart for patient (from patients.csv)."""
    patients = load_csv(PATIENTS_CSV)
    if patients.empty or 'patient_id' not in patients.columns:
        return []
    user = patients[patients['patient_id'] == patient_id]
    if user.empty:
        return []
    cart_str = user.iloc[0].get('cart', '')
    try:
        cart = json.loads(cart_str) if cart_str else []
        return cart
    except:
        return []

def save_patient_cart(patient_id, cart):
    """Persist cart (list) into patients.csv for patient_id."""
    patients = load_csv(PATIENTS_CSV)
    if patients.empty:
        return False
    if 'cart' not in patients.columns:
        patients['cart'] = ''
    idx = patients[patients['patient_id'] == patient_id].index
    if idx.empty:
        return False
    patients.loc[idx, 'cart'] = json.dumps(cart)
    save_csv(patients, PATIENTS_CSV)
    return True

# --- PDF generation for prescriptions ---

def prescription_to_pdf_bytes(presc):
    """Return PDF bytes for a prescription dict using FPDF.

    Robustness improvements:
    - Accept `medicines` that are already lists or JSON strings
    - Coerce non-string diagnosis/notes to strings safely
    - Handle both `str` and `bytes` output from FPDF.output
    """
    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(0, 10, "VitaConnect - Prescription", ln=True, align='C')
    pdf.ln(5)
    pdf.set_font("Arial", size=12)
    pdf.cell(0, 8, f"Prescription ID: {presc.get('prescription_id', '')}", ln=True)
    pdf.cell(0, 8, f"Date: {presc.get('created_at', '')}", ln=True)
    pdf.cell(0, 8, f"Doctor ID: {presc.get('doctor_id', '')}", ln=True)
    pdf.cell(0, 8, f"Patient ID: {presc.get('patient_id', '')}", ln=True)
    pdf.ln(5)
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(0, 8, "Diagnosis:", ln=True)
    pdf.set_font("Arial", size=12)

    # Safe text helpers
    def safe_str(x):
        try:
            if x is None:
                return ""
            # pandas NaN check
            import pandas as _pd
            if isinstance(x, float) and _pd.isna(x):
                return ""
            return str(x)
        except Exception:
            return ""

    pdf.multi_cell(0, 7, safe_str(presc.get('diagnosis', '')))
    pdf.ln(3)
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(0, 8, "Medicines:", ln=True)
    pdf.set_font("Arial", size=12)

    # Normalize medicines field: accept list or JSON string
    meds_field = presc.get('medicines', '[]')
    meds = []
    try:
        if isinstance(meds_field, str):
            meds = json.loads(meds_field) if meds_field.strip() else []
        elif isinstance(meds_field, (list, tuple)):
            meds = list(meds_field)
        else:
            meds = []
    except Exception:
        meds = []

    # create a simple bordered table in PDF for medicines
    pdf.ln(4)
    pdf.set_font("Arial", 'B', 11)
    col_w = [10, 70, 30, 30, 40]  # SNO, Name, Days, Frequency, Before/After
    pdf.cell(col_w[0], 8, "SNO", border=1)
    pdf.cell(col_w[1], 8, "Name of medicine", border=1)
    pdf.cell(col_w[2], 8, "No. of days", border=1)
    pdf.cell(col_w[3], 8, "No. of times", border=1)
    pdf.cell(col_w[4], 8, "Before/After", border=1)
    pdf.ln()
    pdf.set_font("Arial", size=11)

    for idx, m in enumerate(meds, start=1):
        name = safe_str(m.get('name', m.get('medicine_name', ''))) if isinstance(m, dict) else safe_str(m)
        no_of_days = safe_str(m.get('no_of_days', m.get('duration', '')) if isinstance(m, dict) else '')
        times = safe_str(m.get('times_per_day', m.get('frequency', '')) if isinstance(m, dict) else '')
        ba = safe_str(m.get('before_after', '') if isinstance(m, dict) else '')

        pdf.cell(col_w[0], 8, str(idx), border=1)
        pdf.cell(col_w[1], 8, name[:40], border=1)
        pdf.cell(col_w[2], 8, no_of_days, border=1)
        pdf.cell(col_w[3], 8, times, border=1)
        pdf.cell(col_w[4], 8, ba, border=1)
        pdf.ln()

    if presc.get('notes'):
        pdf.ln(3)
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(0, 8, "Notes:", ln=True)
        pdf.set_font("Arial", size=12)
        pdf.multi_cell(0, 7, safe_str(presc.get('notes', '')))

    # return bytes (handle both str and bytes returned by different fpdf versions)
    out = pdf.output(dest='S')
    if isinstance(out, bytes):
        return out
    try:
        return out.encode('latin-1')
    except Exception:
        # fallback to utf-8 with replacement
        return out.encode('utf-8', errors='replace')


# --- CSV normalization helper ---
def ensure_columns(df, columns_defaults: dict):
    """Ensure DataFrame has given columns. Return (df, changed_bool)."""
    changed = False
    if df is None:
        df = pd.DataFrame()
    for col, default in columns_defaults.items():
        if col not in df.columns:
            # If df is empty, add empty column with proper dtype
            if df.empty:
                df[col] = pd.Series(dtype=type(default) if default is not None else object)
            else:
                df[col] = default
            changed = True
    return df, changed

# ============================================================================
# AUTHENTICATION
# ============================================================================

def patient_signup(name, email, password, phone, address):
    df = load_csv(PATIENTS_CSV)
    if not df.empty and email in df['email'].values:
        return False, "Email already registered"
    
    new = pd.DataFrame([{
        'patient_id': generate_id('PAT'),
        'name': name, 'email': email,
        'password': hash_password(password),
        'phone': phone, 'address': address,
        'cart': json.dumps([])
    }])
    
    df = pd.concat([df, new], ignore_index=True)
    save_csv(df, PATIENTS_CSV)
    return True, "Registration successful!"

def patient_login(email, password):
    df = load_csv(PATIENTS_CSV)
    if df.empty:
        return False, None
    user = df[df['email'] == email]
    if user.empty:
        return False, None
    if user.iloc[0]['password'] == hash_password(password):
        return True, user.iloc[0].to_dict()
    return False, None

def doctor_login(email, password):
    df = load_csv(DOCTORS_CSV)
    if df.empty:
        return False, None
    user = df[df['email'] == email]
    if user.empty:
        return False, None
    if user.iloc[0]['password'] == hash_password(password):
        return True, user.iloc[0].to_dict()
    return False, None

# ============================================================================
# PATIENT UI
# ============================================================================

def patient_landing_page():
    """Landing page with feed"""
    st.markdown("<div class='glow'>", unsafe_allow_html=True)
    st.markdown("""
        <h1 style='text-align: center; color: #667eea;'>🏥 VitaConnect</h1>
        <h3 style='text-align: center; color: #764ba2;'>Your Health, Our Priority</h3>
    """, unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("🔐 Patient Login", use_container_width=True, type="primary"):
            st.session_state.page = 'patient_login'
            st.rerun()
        if st.button("📝 New Registration", use_container_width=True):
            st.session_state.page = 'patient_signup'
            st.rerun()
        if st.button("👨‍⚕️ Doctor Login", use_container_width=True):
            st.session_state.page = 'doctor_login'
            st.rerun()
        if st.button("🩺 Doctor Signup", use_container_width=True):
            st.session_state.page = 'doctor_signup'
            st.rerun()
    
    # Health Feed
    st.write("---")
    st.markdown("<h3 style='text-align: center;'>📰 Health Feed</h3>", unsafe_allow_html=True)
    
    health_tips = [
        {"title": "💧 Stay Hydrated", "content": "Drink 8 glasses of water daily for optimal health"},
        {"title": "🏃 Exercise Daily", "content": "30 minutes of physical activity keeps you fit"},
        {"title": "🥗 Eat Healthy", "content": "Include fruits and vegetables in every meal"},
        {"title": "😴 Sleep Well", "content": "Get 7-8 hours of quality sleep every night"},
        {"title": "🧘 Manage Stress", "content": "Practice meditation and yoga for mental peace"},
    ]
    
    for tip in health_tips:
        with st.container():
            st.markdown(f"<div class='glow'>", unsafe_allow_html=True)
            st.write(f"### {tip['title']}")
            st.write(tip['content'])
            st.markdown("</div>", unsafe_allow_html=True)

def patient_signup_page():
    st.title("📝 Patient Registration")
    
    with st.form("signup"):
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input("Full Name*")
            email = st.text_input("Email*")
            phone = st.text_input("Phone*")
        with col2:
            password = st.text_input("Password*", type="password")
            confirm = st.text_input("Confirm Password*", type="password")
        
        address = st.text_area("Address*")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Create Account", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)
        
        if back:
            st.session_state.page = 'landing'
            st.rerun()
        
        if submit:
            if not all([name, email, phone, address, password]):
                st.error("All fields required")
            elif password != confirm:
                st.error("Passwords don't match")
            else:
                success, msg = patient_signup(name, email, password, phone, address)
                if success:
                    st.success(msg)
                    st.balloons()
                    st.session_state.page = 'patient_login'
                    st.rerun()
                else:
                    st.error(msg)

def patient_login_page():
    st.title("🔐 Patient Login")
    
    with st.form("login"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Login", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)
        
        if back:
            st.session_state.page = 'landing'
            st.rerun()
        
        if submit:
            success, user = patient_login(email, password)
            if success:
                st.session_state.user = user
                # load persistent cart
                st.session_state.cart = get_patient_cart(user['patient_id'])
                st.session_state.logged_in = True
                st.session_state.user_type = 'patient'
                st.session_state.page = 'patient_dashboard'
                st.success("Login successful!")
                st.rerun()
            else:
                st.error("Invalid credentials")

def patient_dashboard():
    st.title(f"Welcome, {st.session_state.user['name']}! 👋")
    
    with st.sidebar:
        st.write("### 🎯 Navigation")
        if st.button("🔍 Find Doctors", use_container_width=True):
            st.session_state.page = 'find_doctors'
            st.rerun()
        if st.button("📅 Appointments", use_container_width=True):
            st.session_state.page = 'patient_appointments'
            st.rerun()
        if st.button("💊 Medicine Store", use_container_width=True):
            st.session_state.page = 'medicine_marketplace'
            st.rerun()
        if st.button("📋 Prescriptions", use_container_width=True):
            st.session_state.page = 'patient_prescriptions'
            st.rerun()
        st.write("---")
        if st.button("🚪 Logout", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
    
    # Stats
    appointments = load_csv(APPOINTMENTS_CSV)
    my_apts = appointments[appointments['patient_id'] == st.session_state.user['patient_id']]
    
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Appointments", len(my_apts))
    col2.metric("Upcoming", len(my_apts[my_apts['status'] == 'confirmed']))
    col3.metric("Completed", len(my_apts[my_apts['status'] == 'completed']))
    
    st.write("---")
    
    # Quick actions
    col1, col2, col3 = st.columns(3)
    with col1:
        st.info("### 🔍 Find Doctors")
        if st.button("Search →", key="find", use_container_width=True):
            st.session_state.page = 'find_doctors'
            st.rerun()
    with col2:
        st.info("### 📅 Appointments")
        if st.button("View →", key="apt", use_container_width=True):
            st.session_state.page = 'patient_appointments'
            st.rerun()
    with col3:
        st.info("### 💊 Medicines")
        if st.button("Shop →", key="med", use_container_width=True):
            st.session_state.page = 'medicine_marketplace'
            st.rerun()

def find_doctors_page():
    st.title("🔍 Find Doctors")
    
    with st.sidebar:
        if st.button("← Back", use_container_width=True):
            st.session_state.page = 'patient_dashboard'
            st.rerun()
        
        st.write("### 🎚️ Filters")
        doctors = load_csv(DOCTORS_CSV)
        approved = doctors[doctors['approval_status'] == 'approved']
        
        if approved.empty:
            st.warning("No doctors available")
            return
        
        specs = approved['specialization'].unique().tolist()
        selected_spec = st.selectbox("Specialization", ["All"] + specs)
        
        min_exp, max_exp = st.slider("Experience (years)", 0, 25, (0, 25))
        min_rating = st.slider("Min Rating", 0.0, 5.0, 0.0, 0.5)
        max_fee = st.slider("Max Fee (₹)", 0, 2000, 2000, 100)
    
    # Apply filters
    filtered = approved.copy()
    if selected_spec != "All":
        filtered = filtered[filtered['specialization'] == selected_spec]
    
    # Coerce numeric columns safely before filtering
    exp_series = pd.to_numeric(filtered.get('experience', pd.Series(dtype=float)), errors='coerce').fillna(0).astype(int)
    rating_series = pd.to_numeric(filtered.get('rating', pd.Series(dtype=float)), errors='coerce').fillna(0.0)
    fee_series = pd.to_numeric(filtered.get('fee', pd.Series(dtype=float)), errors='coerce').fillna(0.0)

    filtered = filtered[
        (exp_series >= min_exp) &
        (exp_series <= max_exp) &
        (rating_series >= min_rating) &
        (fee_series <= max_fee)
    ]
    
    st.write(f"### {len(filtered)} Doctors Found")
    
    for idx, doc in filtered.iterrows():
        with st.container():
            st.markdown("<div class='glow'>", unsafe_allow_html=True)
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"### 👨‍⚕️ {doc['name']}")
                st.write(f"**{doc['specialization']}** • {doc.get('experience', '0')} years")
                clinic = doc.get('clinic_address') or doc.get('address') or doc.get('hospital', '')
                if clinic:
                    st.write(f"🏥 {doc.get('hospital', '')} • 📍 {clinic}")
                # show rating and fee with safe formatting
                try:
                    rating_val = float(doc.get('rating', 0.0))
                except:
                    rating_val = 0.0
                try:
                    fee_val = float(doc.get('fee', 0.0))
                except:
                    fee_val = 0.0
                st.write(f"⭐ {rating_val:.1f}/5.0 • 💰 ₹{int(fee_val)}")
            
            with col2:
                st.write("")
                if st.button("Book Now", key=f"book_{doc['doctor_id']}", use_container_width=True, type="primary"):
                    st.session_state.selected_doctor = doc.to_dict()
                    st.session_state.page = 'book_appointment'
                    st.rerun()
            
            st.markdown("</div>", unsafe_allow_html=True)

def book_appointment_page():
    st.title("📅 Book Appointment")
    
    doctor = st.session_state.selected_doctor
    
    st.markdown("<div class='glow'>", unsafe_allow_html=True)
    st.write(f"### {doctor['name']}")
    st.write(f"**{doctor['specialization']}** • {doctor['hospital']}")
    st.write(f"Fee: ₹{doctor['fee']}")
    st.markdown("</div>", unsafe_allow_html=True)
    
    with st.form("booking"):
        col1, col2 = st.columns(2)
        with col1:
            date = st.date_input("Date", min_value=datetime.now().date())
            symptoms = st.text_area("Symptoms (describe briefly)")
        with col2:
            times = [f"{h:02d}:00" for h in range(9, 18)]
            time = st.selectbox("Time", times)
            mode = st.selectbox("Mode", ["In-person", "Online"]) 
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Confirm", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)
        
        if back:
            st.session_state.page = 'find_doctors'
            st.rerun()
        
        if submit:
            appointments = load_csv(APPOINTMENTS_CSV)
            new_apt = pd.DataFrame([{
                'appointment_id': generate_id('APT'),
                'doctor_id': doctor['doctor_id'],
                'patient_id': st.session_state.user['patient_id'],
                'doctor_name': doctor['name'],
                'patient_name': st.session_state.user['name'],
                'date': str(date),
                'time': time,
                'status': 'confirmed',
                'prescription_id': '',
                'symptoms': symptoms,
                'mode': mode,
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }])
            
            appointments = pd.concat([appointments, new_apt], ignore_index=True)
            save_csv(appointments, APPOINTMENTS_CSV)
            
            # set flag so patient appointments page can show confirmation after rerun
            st.session_state.just_booked = True
            st.success("Appointment booked!")
            st.balloons()
            time_module.sleep(0.3)
            st.session_state.page = 'patient_appointments'
            st.rerun()


def patient_appointments_page():
    st.title("📅 My Appointments")
    
    with st.sidebar:
        if st.button("← Back", use_container_width=True):
            st.session_state.page = 'patient_dashboard'
            st.rerun()
    
    appointments = load_csv(APPOINTMENTS_CSV)
    my_appts_all = appointments[appointments['patient_id'] == st.session_state.user['patient_id']].copy()
    # Sort by booking time (created_at) descending. Use safe datetime parsing.
    my_appts_all['created_at_dt'] = pd.to_datetime(my_appts_all.get('created_at', ''), errors='coerce')
    my_apts = my_appts_all.sort_values(by='created_at_dt', ascending=False)
    
    if my_apts.empty:
        st.info("No appointments yet")
        return

    # Show booking confirmation if we just booked an appointment
    if st.session_state.get('just_booked'):
        st.success("Appointment booked successfully!")
        st.balloons()
        try:
            del st.session_state['just_booked']
        except Exception:
            pass
    
    for idx, apt in my_apts.iterrows():
        st.markdown("<div class='glow'>", unsafe_allow_html=True)
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.write(f"### 👨‍⚕️ {apt['doctor_name']}")
            st.write(f"📅 {apt['date']} • ⏰ {apt['time']}")
            status_emoji = {'confirmed': '🟢', 'completed': '🔵', 'cancelled': '🔴'}.get(apt['status'], '⚪')
            st.write(f"{status_emoji} {apt['status'].title()}")
            
            # Show prescription if exists
            if apt.get('prescription_id'):
                st.info(f"📋 Prescription: {apt['prescription_id']}")
        
        with col2:
            if apt['status'] == 'confirmed':
                if st.button("Cancel", key=f"cancel_{apt['appointment_id']}", use_container_width=True):
                    appointments.loc[appointments['appointment_id'] == apt['appointment_id'], 'status'] = 'cancelled'
                    save_csv(appointments, APPOINTMENTS_CSV)
                    st.success("Appointment cancelled")
                    st.rerun()
        
        st.markdown("</div>", unsafe_allow_html=True)

def patient_prescriptions_page():
    st.title("📋 My Prescriptions")
    
    with st.sidebar:
        if st.button("← Back", use_container_width=True):
            st.session_state.page = 'patient_dashboard'
            st.rerun()
    
    prescriptions = load_csv(PRESCRIPTIONS_CSV)
    my_presc = prescriptions[
        prescriptions['patient_id'] == st.session_state.user['patient_id']
    ].sort_values('created_at', ascending=False)
    
    if my_presc.empty:
        st.info("No prescriptions yet")
        return

    # Download all prescriptions as ZIP
    if len(my_presc) > 1:
        try:
            import io, zipfile, traceback
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, 'w') as z:
                for _, presc in my_presc.iterrows():
                    pdf_bytes = prescription_to_pdf_bytes(presc.to_dict())
                    z.writestr(f"{presc['prescription_id']}.pdf", pdf_bytes)
            buf.seek(0)
            st.download_button("📥 Download All Prescriptions (ZIP)", data=buf.read(), file_name=f"prescriptions_{st.session_state.user['patient_id']}.zip", mime='application/zip')
        except Exception as e:
            st.error(f"Bulk download failed: {e}")
            print(traceback.format_exc())
    
    for idx, presc in my_presc.iterrows():
        st.markdown("<div class='glow'>", unsafe_allow_html=True)
        st.write(f"### 📋 Prescription - {presc['created_at'][:10]}")
        st.write(f"**Diagnosis:** {presc['diagnosis']}")
        
        medicines = json.loads(presc['medicines'])
        st.write("**Medicines:**")
        # build HTML table (dark background with light text)
        table_html = "<table style='border-collapse: collapse; width: 100%; background: #0b1220;'>"
        table_html += "<tr style='border:1px solid #333; background:#111;'><th style='border:1px solid #333;padding:8px;color:#eee;'>SNO</th><th style='border:1px solid #333;padding:8px;color:#eee;'>Name of medicine</th><th style='border:1px solid #333;padding:8px;color:#eee;'>No. of days</th><th style='border:1px solid #333;padding:8px;color:#eee;'>No. of times</th><th style='border:1px solid #333;padding:8px;color:#eee;'>Before/After meal</th></tr>"
        for i, med in enumerate(medicines, start=1):
            table_html += f"<tr style='border:1px solid #333; background:#111;'><td style='border:1px solid #333;padding:6px;color:#eee;'>{i}</td>"
            table_html += f"<td style='border:1px solid #333;padding:6px;color:#eee;'>{med.get('name','')}</td>"
            table_html += f"<td style='border:1px solid #333;padding:6px;color:#eee;'>{med.get('no_of_days', med.get('duration',''))}</td>"
            table_html += f"<td style='border:1px solid #333;padding:6px;color:#eee;'>{med.get('times_per_day', med.get('frequency',''))}</td>"
            table_html += f"<td style='border:1px solid #333;padding:6px;color:#eee;'>{med.get('before_after','')}</td></tr>"
        table_html += "</table>"
        st.markdown(table_html, unsafe_allow_html=True)
        
        if presc.get('notes'):
            st.write(f"**Notes:** {presc['notes']}")
        
        col1, col2 = st.columns([2, 1])
        with col1:
            if st.button("💊 Order Medicines", key=f"order_{presc['prescription_id']}", use_container_width=True):
                st.session_state.order_prescription = presc.to_dict()
                st.session_state.page = 'order_from_prescription'
                st.rerun()
        with col2:
            try:
                pdf_bytes = prescription_to_pdf_bytes(presc.to_dict())
                st.download_button(label="📄 Download PDF", data=pdf_bytes, file_name=f"{presc['prescription_id']}.pdf", mime="application/pdf")
            except Exception as e:
                # surface helpful error to user and log stack to server output
                st.error(f"PDF generation failed: {e}")
                import traceback
                print("PDF generation error:\n", traceback.format_exc())
        # show notes if any
        if presc.get('notes'):
            st.write(f"**Notes:** {presc['notes']}")
        # show original appointment symptoms if available
        try:
            appointments = load_csv(APPOINTMENTS_CSV)
            apt_row = appointments[appointments['appointment_id'] == presc['appointment_id']]
            if not apt_row.empty and apt_row.iloc[0].get('symptoms'):
                st.info(f"Patient reported symptoms: {apt_row.iloc[0].get('symptoms')}")
        except:
            pass
        
        st.markdown("</div>", unsafe_allow_html=True)

def medicine_marketplace():
    st.title("💊 Medicine Marketplace")
    
    with st.sidebar:
        if st.button("← Back", use_container_width=True):
            st.session_state.page = 'patient_dashboard'
            st.rerun()
        
        st.write("### 🛒 Cart")
        cart = st.session_state.get('cart', [])
        if cart:
            total = sum(item['price'] * item['quantity'] for item in cart)
            st.write(f"**Items:** {len(cart)}")
            st.write(f"**Total:** ₹{total}")
            if st.button("Checkout", use_container_width=True, type="primary"):
                st.session_state.page = 'checkout'
                st.rerun()
        else:
            st.write("Empty")
    
    medicines = load_csv(MEDICINES_CSV)
    
    # Filters
    tab1, tab2 = st.tabs(["🌟 General Purpose", "🏥 Specialized"])
    
    with tab1:
        general = medicines[medicines['type'] == 'General']
        categories = general['category'].unique().tolist()
        selected_cat = st.selectbox("Category", ["All"] + categories, key="gen_cat")
        
        filtered = general if selected_cat == "All" else general[general['category'] == selected_cat]
        
        for idx, med in filtered.iterrows():
            st.markdown("<div class='glow'>", unsafe_allow_html=True)
            col1, col2, col3 = st.columns([3, 1, 1])
            
            with col1:
                st.write(f"### 💊 {med['name']}")
                st.write(f"**{med['category']}** • {med['manufacturer']}")
                st.write(f"💰 ₹{med['price']} • Stock: {med['stock']}")
            
            with col2:
                qty = st.number_input("Qty", 1, 10, 1, key=f"qty_gen_{idx}")
            
            with col3:
                st.write("")
                if st.button("Add", key=f"add_gen_{idx}", use_container_width=True):
                    cart = st.session_state.get('cart', [])
                    cart.append({
                        'medicine_id': med['medicine_id'],
                        'name': med['name'],
                        'price': med['price'],
                        'quantity': qty
                    })
                    st.session_state.cart = cart
                    st.success("Added!")
                    st.rerun()
            
            st.markdown("</div>", unsafe_allow_html=True)
    
    with tab2:
        specialized = medicines[medicines['type'] == 'Specialized']
        categories = specialized['category'].unique().tolist()
        selected_cat = st.selectbox("Category", ["All"] + categories, key="spec_cat")
        
        filtered = specialized if selected_cat == "All" else specialized[specialized['category'] == selected_cat]
        
        for idx, med in filtered.iterrows():
            st.markdown("<div class='glow'>", unsafe_allow_html=True)
            col1, col2, col3 = st.columns([3, 1, 1])
            
            with col1:
                st.write(f"### 💊 {med['name']}")
                st.write(f"**{med['category']}** • {med['manufacturer']}")
                st.write(f"💰 ₹{med['price']} • Stock: {med['stock']}")
            
            with col2:
                qty = st.number_input("Qty", 1, 10, 1, key=f"qty_spec_{idx}")
            
            with col3:
                st.write("")
                if st.button("Add", key=f"add_spec_{idx}", use_container_width=True):
                    cart = st.session_state.get('cart', [])
                    cart.append({
                        'medicine_id': med['medicine_id'],
                        'name': med['name'],
                        'price': med['price'],
                        'quantity': qty
                    })
                    st.session_state.cart = cart
                    st.success("Added!")
                    st.rerun()
            
            st.markdown("</div>", unsafe_allow_html=True)

def order_from_prescription():
    st.title("💊 Order from Prescription")
    
    presc = st.session_state.order_prescription
    medicines = json.loads(presc['medicines'])
    
    st.write("### Prescribed Medicines")
    
    # Auto-add to cart
    if 'auto_added' not in st.session_state:
        st.session_state.cart = []
        meds_df = load_csv(MEDICINES_CSV)
        
        for med in medicines:
            # Find medicine
            found = meds_df[meds_df['name'].str.contains(med['name'].split()[0], case=False, na=False)]
            # compute quantity from prescription fields if available
            try:
                if med.get('quantity'):
                    qty = int(med.get('quantity'))
                else:
                    times = int(med.get('times_per_day') or med.get('frequency') or 0)
                    days = int(med.get('no_of_days') or 0)
                    qty = times * days if times and days else 1
            except Exception:
                qty = 1
            if not found.empty:
                med_data = found.iloc[0]
                st.session_state.cart.append({
                    'medicine_id': med_data['medicine_id'],
                    'name': med_data['name'],
                    'price': med_data['price'],
                    'quantity': qty,
                    'times_per_day': med.get('times_per_day', med.get('frequency', '')),
                    'no_of_days': med.get('no_of_days', ''),
                    'before_after': med.get('before_after', '')
                })
            else:
                st.session_state.cart.append({
                    'medicine_id': '',
                    'name': med.get('name', ''),
                    'price': 0,
                    'quantity': qty,
                    'times_per_day': med.get('times_per_day', med.get('frequency', '')),
                    'no_of_days': med.get('no_of_days', ''),
                    'before_after': med.get('before_after', '')
                })
        st.session_state.auto_added = True
    
    for item in st.session_state.cart:
        st.write(f"✓ {item['name']} - ₹{item['price']} x {item['quantity']}")
    
    total = sum(item['price'] * item['quantity'] for item in st.session_state.cart)
    st.write(f"### Total: ₹{total}")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Proceed to Checkout", use_container_width=True, type="primary"):
            st.session_state.page = 'checkout'
            st.rerun()
    with col2:
        if st.button("← Back", use_container_width=True):
            del st.session_state.auto_added
            st.session_state.page = 'patient_prescriptions'
            st.rerun()

def checkout_page():
    st.title("🛒 Checkout")
    
    cart = st.session_state.get('cart', [])
    if not cart:
        st.warning("Cart is empty")
        return
    
    st.write("### Order Summary")
    subtotal = 0
    
    for item in cart:
        col1, col2, col3 = st.columns([3, 1, 1])
        with col1:
            st.write(item['name'])
        with col2:
            st.write(f"Qty: {item['quantity']}")
        with col3:
            total = item['price'] * item['quantity']
            st.write(f"₹{total}")
            subtotal += total
    
    st.write("---")
    delivery = 50
    grand_total = subtotal + delivery
    
    st.write(f"**Subtotal:** ₹{subtotal}")
    st.write(f"**Delivery:** ₹{delivery}")
    st.write(f"**Grand Total:** ₹{grand_total}")
    
    with st.form("checkout"):
        address = st.text_area("Delivery Address", value=st.session_state.user.get('address', ''))
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Place Order", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)
        
        if back:
            st.session_state.page = 'medicine_marketplace'
            st.rerun()
        
        if submit:
            order_data = {
                'order_id': generate_id('ORD'),
                'patient_id': st.session_state.user['patient_id'],
                'prescription_id': st.session_state.get('order_prescription', {}).get('prescription_id', 'DIRECT'),
                'medicines': json.dumps(cart),
                'total_amount': grand_total,
                'delivery_address': address,
                'status': 'confirmed',
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            orders = load_csv(ORDERS_CSV)
            new_order = pd.DataFrame([order_data])
            orders = pd.concat([orders, new_order], ignore_index=True)
            save_csv(orders, ORDERS_CSV)
            
            st.session_state.cart = []
            if 'auto_added' in st.session_state:
                del st.session_state.auto_added
            
            st.success("Order placed successfully!")
            st.balloons()
            st.session_state.page = 'patient_dashboard'
            st.rerun()

# ============================================================================
# DOCTOR UI
# ============================================================================

def doctor_login_page():
    st.title("👨‍⚕️ Doctor Login")
    
    st.info("**Demo:** Use any doctor email (e.g., rajeshsharma@gmail.com) with password: doc123")
    
    with st.form("doctor_login"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Login", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)
        
        if back:
            st.session_state.page = 'landing'
            st.rerun()
        
        if submit:
            success, user = doctor_login(email, password)
            if success:
                if user.get('approval_status') != 'approved':
                    st.warning("Your account is not approved yet. Please wait for admin approval.")
                else:
                    st.session_state.user = user
                    st.session_state.logged_in = True
                    st.session_state.user_type = 'doctor'
                    st.session_state.page = 'doctor_dashboard'
                    st.success("Login successful!")
                    st.rerun()
            else:
                st.error("Invalid credentials")

    # Quick link to doctor registration
    if st.button("📝 New Doctor Registration", use_container_width=True):
        st.session_state.page = 'doctor_signup'
        st.rerun()


def doctor_signup_page():
    st.title("📝 Doctor Registration")
    st.info("Clinic address and consultation fee are required for registration. Admin will review your application.")

    with st.form("doctor_signup"):
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input("Full Name*")
            email = st.text_input("Email*")
            phone = st.text_input("Phone*")
            degree = st.text_input("Degree (e.g., MBBS, MD)")
            specialization = st.text_input("Specialization*")
        with col2:
            password = st.text_input("Password*", type="password")
            confirm = st.text_input("Confirm Password*", type="password")
            hospital = st.text_input("Clinic/Hospital Name*")
            clinic_address = st.text_area("Clinic Address*")
            fee = st.number_input("Consultation Fee (₹)*", min_value=0, value=500)
            rating = st.number_input("Initial Rating (0-5)", min_value=0.0, max_value=5.0, value=0.0, step=0.1)

        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Create Account", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)

        if back:
            st.session_state.page = 'landing'
            st.rerun()

        if submit:
            if not all([name, email, phone, specialization, hospital, clinic_address, password]):
                st.error("All fields marked * are required")
            elif password != confirm:
                st.error("Passwords don't match")
            else:
                # check duplicates
                df = load_csv(DOCTORS_CSV)
                if not df.empty and email in df['email'].values:
                    st.error("Email already registered")
                else:
                    new_doc = pd.DataFrame([{
                        'doctor_id': generate_id('DOC'),
                        'name': name,
                        'email': email,
                        'password': hash_password(password),
                        'phone': phone,
                        'city': 'Unknown',
                        'state': '',
                        'degree': degree,
                        'specialization': specialization,
                        'experience': '0',
                        'hospital': hospital,
                        'address': clinic_address,
                        'clinic_address': clinic_address,
                        'rating': float(rating),
                        'fee': float(fee),
                        'approval_status': 'pending',
                        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    }])
                    df = pd.concat([df, new_doc], ignore_index=True)
                    save_csv(df, DOCTORS_CSV)
                    st.success("Registration submitted — awaiting admin approval")
                    st.session_state.page = 'doctor_login'
                    st.rerun()

def doctor_dashboard():
    st.title(f"Welcome, {st.session_state.user['name']}!")
    
    with st.sidebar:
        st.write("### 🏥 Doctor Portal")
        if st.button("📅 Appointments", use_container_width=True):
            st.session_state.page = 'doctor_appointments'
            st.rerun()
        if st.button("👤 Profile", use_container_width=True):
            st.session_state.page = 'doctor_profile'
            st.rerun()
        st.write("---")
        if st.button("🚪 Logout", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
    
    appointments = load_csv(APPOINTMENTS_CSV)
    my_apts = appointments[appointments['doctor_id'] == st.session_state.user['doctor_id']]
    today = datetime.now().date()
    today_apts = my_apts[my_apts['date'] == str(today)]
    
    col1, col2, col3 = st.columns(3)
    col1.metric("Today", len(today_apts))
    col2.metric("Upcoming", len(my_apts[my_apts['status'] == 'confirmed']))
    col3.metric("Completed", len(my_apts[my_apts['status'] == 'completed']))
    
    st.write("---")
    st.write("### Today's Schedule")
    
    if today_apts.empty:
        st.info("No appointments today")
    else:
        for idx, apt in today_apts.iterrows():
            st.markdown("<div class='glow'>", unsafe_allow_html=True)
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"**👤 {apt['patient_name']}**")
                st.write(f"⏰ {apt['time']} • {apt['status'].title()}")
                if apt.get('symptoms'):
                    st.info(f"Symptoms: {apt.get('symptoms')}")
            
            with col2:
                if apt['status'] == 'confirmed':
                    if st.button("Complete", key=f"comp_{apt['appointment_id']}", use_container_width=True):
                        st.session_state.current_appointment = apt.to_dict()
                        st.session_state.page = 'create_prescription'
                        st.rerun()
            
            st.markdown("</div>", unsafe_allow_html=True)

def doctor_appointments_page():
    st.title("📅 My Appointments")
    
    with st.sidebar:
        if st.button("← Back", use_container_width=True):
            st.session_state.page = 'doctor_dashboard'
            st.rerun()
    
    appointments = load_csv(APPOINTMENTS_CSV)
    my_apts = appointments[
        appointments['doctor_id'] == st.session_state.user['doctor_id']
    ].sort_values('date', ascending=False)
    
    # Show confirmation if a prescription was just created
    if st.session_state.get('just_prescribed'):
        st.success("Prescription created and patient cart updated!")
        st.balloons()
        try:
            del st.session_state['just_prescribed']
        except Exception:
            pass

    if my_apts.empty:
        st.info("No appointments")
        return
    
    for idx, apt in my_apts.iterrows():
        st.markdown("<div class='glow'>", unsafe_allow_html=True)
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.write(f"### 👤 {apt['patient_name']}")
            st.write(f"📅 {apt['date']} • ⏰ {apt['time']}")
            st.write(f"Status: {apt['status'].title()}")
            if apt.get('symptoms'):
                st.info(f"Symptoms: {apt.get('symptoms')}")
        
        with col2:
            st.write("")
            if apt['status'] == 'confirmed':
                if st.button("✅ Complete", key=f"comp2_{apt['appointment_id']}", use_container_width=True):
                    st.session_state.current_appointment = apt.to_dict()
                    st.session_state.page = 'create_prescription'
                    st.rerun()
                
                if st.button("📋 Prescribe", key=f"presc_{apt['appointment_id']}", use_container_width=True):
                    st.session_state.current_appointment = apt.to_dict()
                    st.session_state.page = 'create_prescription'
                    st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)

def doctor_profile_page():
    st.title("👤 My Profile")
    
    with st.sidebar:
        if st.button("← Back", use_container_width=True):
            st.session_state.page = 'doctor_dashboard'
            st.rerun()
    
    doc = st.session_state.user
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("<div class='glow'>", unsafe_allow_html=True)
        st.write("### Professional Info")
        st.write(f"**Name:** {doc['name']}")
        st.write(f"**Specialization:** {doc['specialization']}")
        st.write(f"**Degree:** {doc['degree']}")
        st.write(f"**Experience:** {doc['experience']} years")
        st.write(f"**Rating:** ⭐ {doc['rating']}/5.0")
        st.markdown("</div>", unsafe_allow_html=True)
    
    with col2:
        st.markdown("<div class='glow'>", unsafe_allow_html=True)
        st.write("### Hospital Details")
        st.write(f"**Hospital:** {doc['hospital']}")
        st.write(f"**Address:** {doc['address']}")
        st.write(f"**Phone:** {doc['phone']}")
        st.write(f"**Email:** {doc['email']}")
        st.write(f"**Fee:** ₹{doc['fee']}")
        st.markdown("</div>", unsafe_allow_html=True)

def create_prescription_page():
    st.title("📋 Create Prescription")
    
    apt = st.session_state.current_appointment
    
    st.markdown("<div class='glow'>", unsafe_allow_html=True)
    st.write(f"**Patient:** {apt['patient_name']}")
    st.write(f"**Date:** {apt['date']} • {apt['time']}")
    st.markdown("</div>", unsafe_allow_html=True)
    
    with st.form("prescription"):
        diagnosis = st.text_area("Diagnosis*", placeholder="Enter diagnosis...")
        
        st.write("### Select Medicines")
        
        medicines_df = load_csv(MEDICINES_CSV)
        
        # Get doctor's specialty medicines
        doc_specialty = st.session_state.user['specialization']
        specialty_meds = medicines_df[medicines_df['category'] == doc_specialty.replace('ist', 'logy')]
        general_meds = medicines_df[medicines_df['type'] == 'General']
        
        all_meds = pd.concat([specialty_meds, general_meds]).drop_duplicates()
        
        num_meds = st.number_input("Number of medicines", 1, 10, 3)
        
        selected_medicines = []
        
        for i in range(num_meds):
                st.write(f"**Medicine {i+1}**")
                col1, col2 = st.columns(2)
                
                with col1:
                    med_name = st.selectbox(
                        f"Select Medicine",
                        options=all_meds['name'].tolist(),
                        key=f"med_{i}"
                    )
                    dosage = st.text_input(f"Dosage", placeholder="e.g., 1 tablet", key=f"dose_{i}")
                    times_per_day = st.number_input(f"Times per day", min_value=1, value=2, key=f"times_{i}")
                    before_after = st.selectbox(f"Before/After Meal", ["After meal", "Before meal", "Any"], key=f"ba_{i}")
                
                with col2:
                    no_of_days = st.selectbox(f"No. of days", [3,5,7,10,14,21,30], index=2, key=f"days_{i}")
                    instructions = st.text_input(f"Instructions", placeholder="After meals", key=f"inst_{i}")
                    # computed quantity = times_per_day * no_of_days
                    total_qty = int(times_per_day) * int(no_of_days)
                    st.info(f"Calculated quantity: {total_qty}")
                
                if med_name and dosage:
                    selected_medicines.append({
                        'name': med_name,
                        'dosage': dosage,
                        'times_per_day': int(times_per_day),
                        'quantity': int(total_qty),
                        'no_of_days': int(no_of_days),
                        'before_after': before_after,
                        'instructions': instructions
                    })
        notes = st.text_area("Additional Notes")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Generate Prescription", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)
        
        if back:
            st.session_state.page = 'doctor_appointments'
            st.rerun()
        
        if submit:
            if not diagnosis or not selected_medicines:
                st.error("Diagnosis and at least one medicine required")
            else:
                prescription_data = {
                    'prescription_id': generate_id('PRESC'),
                    'appointment_id': apt['appointment_id'],
                    'patient_id': apt['patient_id'],
                    'doctor_id': st.session_state.user['doctor_id'],
                    'medicines': json.dumps(selected_medicines),
                    'diagnosis': diagnosis,
                    'notes': notes,
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                prescriptions = load_csv(PRESCRIPTIONS_CSV)
                new_presc = pd.DataFrame([prescription_data])
                prescriptions = pd.concat([prescriptions, new_presc], ignore_index=True)
                save_csv(prescriptions, PRESCRIPTIONS_CSV)
                
                # Update appointment with prescription and mark completed
                appointments = load_csv(APPOINTMENTS_CSV)
                appointments.loc[
                    appointments['appointment_id'] == apt['appointment_id'],
                    'prescription_id'
                ] = prescription_data['prescription_id']
                appointments.loc[
                    appointments['appointment_id'] == apt['appointment_id'],
                    'status'
                ] = 'completed'
                save_csv(appointments, APPOINTMENTS_CSV)
                
                # Add medicines to patient's persistent cart (use quantity if provided)
                try:
                    meds = selected_medicines
                    meds_df = load_csv(MEDICINES_CSV)
                    current_cart = get_patient_cart(prescription_data['patient_id'])
                    for med in meds:
                        # try to find medicine entry to get id/price
                        found = meds_df[meds_df['name'].str.contains(med['name'].split()[0], case=False, na=False)]
                        qty = int(med.get('quantity', 1))
                        if not found.empty:
                            mrow = found.iloc[0]
                            item = {
                                'medicine_id': mrow['medicine_id'],
                                'name': mrow['name'],
                                'price': float(mrow['price']),
                                'quantity': qty,
                                'times_per_day': med.get('times_per_day', med.get('frequency', '')),
                                'no_of_days': med.get('no_of_days', ''),
                                'before_after': med.get('before_after', '')
                            }
                        else:
                            item = {
                                'medicine_id': '',
                                'name': med['name'],
                                'price': 0,
                                'quantity': qty,
                                'times_per_day': med.get('times_per_day', med.get('frequency', '')),
                                'no_of_days': med.get('no_of_days', ''),
                                'before_after': med.get('before_after', '')
                            }
                        current_cart.append(item)
                    save_patient_cart(prescription_data['patient_id'], current_cart)
                except Exception as e:
                    # don't block prescription save if cart update fails
                    print("Failed to add meds to cart:", e)

                # set session flags so doctor sees confirmation and patient can see on next login/view
                st.session_state.just_prescribed = True
                st.session_state.last_prescription_id = prescription_data['prescription_id']
                st.success("Prescription created successfully and patient cart updated!")
                st.balloons()
                time_module.sleep(0.3)
                st.session_state.page = 'doctor_appointments'
                st.rerun()

# ============================================================================
# ADMIN UI
# ============================================================================

def admin_login_page():
    st.title("🛡️ Admin Login")
    
    with st.form("admin_login"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit = st.form_submit_button("Login", use_container_width=True, type="primary")
        with col2:
            back = st.form_submit_button("← Back", use_container_width=True)
        
        if back:
            st.session_state.page = 'landing'
            st.rerun()
        
        if submit:
            if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
                st.session_state.logged_in = True
                st.session_state.user_type = 'admin'
                st.session_state.page = 'admin_dashboard'
                st.success("Admin login successful!")
                st.rerun()
            else:
                st.error("Invalid credentials")

def admin_dashboard():
    st.title("🛡️ Admin Dashboard")
    
    with st.sidebar:
        if st.button("🚪 Logout", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
    
    doctors = load_csv(DOCTORS_CSV)
    patients = load_csv(PATIENTS_CSV)
    appointments = load_csv(APPOINTMENTS_CSV)
    orders = load_csv(ORDERS_CSV)
    prescriptions = load_csv(PRESCRIPTIONS_CSV)
    
    # High level metrics
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Doctors", len(doctors))
    col2.metric("Patients", len(patients))
    col3.metric("Appointments", len(appointments))
    col4.metric("Orders", len(orders))
    
    st.write("---")

    # Appointments by status
    try:
        status_counts = appointments['status'].value_counts()
        st.subheader("Appointments by Status")
        st.bar_chart(status_counts)
    except Exception:
        st.info("No appointment status data yet")
    
    # Revenue
    try:
        total_revenue = orders['total_amount'].astype(float).sum()
        st.metric("Total Revenue (₹)", f"{total_revenue:,}")
    except Exception:
        st.info("No revenue data yet")
    
    # Prescriptions
    st.write(f"**Prescriptions:** {len(prescriptions)}")
    
    # Top medicines from orders
    med_counts = {}
    try:
        for _, row in orders.iterrows():
            meds = json.loads(row.get('medicines', '[]'))
            for m in meds:
                name = m.get('name')
                med_counts[name] = med_counts.get(name, 0) + m.get('quantity', 1)
        if med_counts:
            st.subheader("Top Medicines Ordered")
            med_df = pd.DataFrame(list(med_counts.items()), columns=['name', 'count']).sort_values('count', ascending=False).head(10).set_index('name')
            st.bar_chart(med_df)
    except Exception:
        st.info("No order medicine data yet")

    st.write("---")

    # Doctor analytics
    st.subheader("Doctor Analytics")
    try:
        doc_ratings = pd.to_numeric(doctors.get('rating', pd.Series(dtype=float)), errors='coerce').dropna()
        doc_fees = pd.to_numeric(doctors.get('fee', pd.Series(dtype=float)), errors='coerce').dropna()
        avg_rating = f"{doc_ratings.mean():.2f}" if not doc_ratings.empty else "N/A"
        avg_fee = f"{doc_fees.mean():.0f}" if not doc_fees.empty else "N/A"
        col1, col2, col3 = st.columns(3)
        col1.metric("Avg Rating", avg_rating)
        col2.metric("Avg Fee (₹)", avg_fee)
        col3.metric("Total Doctors", len(doctors))

        # Doctors by specialization
        if 'specialization' in doctors.columns:
            spec_counts = doctors['specialization'].value_counts().head(10)
            if not spec_counts.empty:
                st.write("Top Specializations")
                st.bar_chart(pd.DataFrame(spec_counts))

        # Doctors by approval status
        if 'approval_status' in doctors.columns:
            status_counts = doctors['approval_status'].value_counts()
            if not status_counts.empty:
                st.write("Doctors by Status")
                st.bar_chart(pd.DataFrame(status_counts))

        # Top doctors by appointments
        try:
            top_docs = appointments['doctor_id'].value_counts().head(5)
            if not top_docs.empty:
                top_df = top_docs.rename_axis('doctor_id').reset_index(name='count')
                top_df = top_df.merge(doctors[['doctor_id','name']], on='doctor_id', how='left')
                top_df = top_df[['name','count']].set_index('name')
                st.write("Top Doctors by Appointments")
                st.bar_chart(top_df)
        except Exception:
            pass
    except Exception:
        st.info("Not enough doctor data for analytics")

    st.write("---")

    # Doctor management
    st.subheader("Doctor Applications & Management")
    pending = doctors[doctors['approval_status'] == 'pending'] if not doctors.empty else pd.DataFrame()
    if not pending.empty:
        st.write("### Pending Applications")
        for idx, d in pending.iterrows():
            st.markdown("<div class='glow'>", unsafe_allow_html=True)
            st.write(f"**{d['name']}** — {d.get('specialization', '')}")
            st.write(f"Clinic: {d.get('clinic_address', d.get('address', ''))}")
            col1, col2, col3 = st.columns([2,1,1])
            with col1:
                if st.button("View", key=f"view_pending_{d['doctor_id']}"):
                    st.session_state.admin_view_doctor = d.to_dict()
                
            with col2:
                if st.button("Approve", key=f"approve_{d['doctor_id']}"):
                    doctors.loc[doctors['doctor_id'] == d['doctor_id'], 'approval_status'] = 'approved'
                    save_csv(doctors, DOCTORS_CSV)
                    st.rerun()
            with col3:
                if st.button("Reject", key=f"reject_{d['doctor_id']}"):
                    doctors.loc[doctors['doctor_id'] == d['doctor_id'], 'approval_status'] = 'rejected'
                    save_csv(doctors, DOCTORS_CSV)
                    st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.info("No pending doctor applications")

    st.write("---")
    st.write("### All Doctors")
    if not doctors.empty:
        for idx, d in doctors.iterrows():
            st.markdown("<div class='glow'>", unsafe_allow_html=True)
            st.write(f"**{d['name']}** — {d.get('specialization', '')} — Status: {d.get('approval_status')}")
            st.write(f"Clinic: {d.get('clinic_address', d.get('address', ''))}")
            col1, col2 = st.columns([3,1])
            with col1:
                if st.button("View Details", key=f"view_doc_{d['doctor_id']}"):
                    st.session_state.admin_view_doctor = d.to_dict()
            with col2:
                if d.get('approval_status') == 'approved':
                    if st.button("Revoke", key=f"revoke_{d['doctor_id']}"):
                        doctors.loc[doctors['doctor_id'] == d['doctor_id'], 'approval_status'] = 'revoked'
                        save_csv(doctors, DOCTORS_CSV)
                        st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.info("No doctors in system")

    # show admin_view_doctor details if set
    if st.session_state.get('admin_view_doctor'):
        d = st.session_state.get('admin_view_doctor')
        st.write("---")
        st.subheader(f"Doctor Details — {d.get('name')}")
        st.write(f"**Email:** {d.get('email')}")
        st.write(f"**Phone:** {d.get('phone')}")
        st.write(f"**Specialization:** {d.get('specialization')}")
        st.write(f"**Degree:** {d.get('degree')}")
        st.write(f"**Experience:** {d.get('experience')}")
        st.write(f"**Clinic:** {d.get('clinic_address', d.get('address', ''))}")
        st.write(f"**Rating:** {d.get('rating')}")
        st.write(f"**Fee:** ₹{d.get('fee')}")

    # Orders section for admin to view full order details
    st.write("---")
    st.subheader("Orders")
    orders = load_csv(ORDERS_CSV)
    if orders.empty:
        st.info("No orders yet.")
    else:
        orders['created_at'] = pd.to_datetime(orders.get('created_at',''), errors='coerce')
        orders = orders.sort_values(by='created_at', ascending=False)
        for _, ord_row in orders.iterrows():
            with st.expander(f"Order {ord_row.get('order_id')} - {ord_row.get('status','')}"):
                st.write("Placed by:", ord_row.get('patient_id'))
                total_field = ord_row.get('total_amount', ord_row.get('total', ord_row.get('total_amount', '')))
                st.write("Total:", total_field)
                # Show items as table
                try:
                    items = json.loads(ord_row.get('medicines', '[]'))
                    if items:
                        items_df = pd.DataFrame(items)
                        st.dataframe(items_df)
                    else:
                        st.write("No items")
                except Exception as e:
                    st.error(f"Failed to decode items: {e}")
                st.write("Delivery Address:", ord_row.get('delivery_address'))
                st.write("Status:", ord_row.get('status'))
                # Raw metadata
                meta = {k: ord_row.get(k) for k in ord_row.index if k not in ['medicines']}
                st.json(meta)

    st.success("✅ All systems operational")

# ============================================================================
# MAIN ROUTER
# ============================================================================

def main():
    st.set_page_config(
        page_title="VitaConnect",
        page_icon="🏥",
        layout="wide"
    )
    
    init_csv_files()
    apply_animations()
    
    # Settings
    with st.sidebar:
        st.write("### ⚙️ Settings")
        st.write("---")
    
    if 'page' not in st.session_state:
        st.session_state.page = 'landing'
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    
    # Admin access
    if not st.session_state.logged_in:
        with st.sidebar:
            if st.button("🛡️ Admin", use_container_width=True):
                st.session_state.page = 'admin_login'
                st.rerun()
    
    page = st.session_state.page
    
    # Routing
    if page == 'landing':
        patient_landing_page()
    elif page == 'patient_signup':
        patient_signup_page()
    elif page == 'patient_login':
        patient_login_page()
    elif page == 'patient_dashboard':
        patient_dashboard()
    elif page == 'find_doctors':
        find_doctors_page()
    elif page == 'book_appointment':
        book_appointment_page()
    elif page == 'patient_appointments':
        patient_appointments_page()
    elif page == 'patient_prescriptions':
        patient_prescriptions_page()
    elif page == 'medicine_marketplace':
        medicine_marketplace()
    elif page == 'order_from_prescription':
        order_from_prescription()
    elif page == 'checkout':
        checkout_page()
    elif page == 'doctor_login':
        doctor_login_page()
    elif page == 'doctor_signup':
        doctor_signup_page()
    elif page == 'doctor_dashboard':
        doctor_dashboard()
    elif page == 'doctor_appointments':
        doctor_appointments_page()
    elif page == 'doctor_profile':
        doctor_profile_page()
    elif page == 'create_prescription':
        create_prescription_page()
    elif page == 'admin_login':
        admin_login_page()
    elif page == 'admin_dashboard':
        admin_dashboard()

if __name__ == "__main__":
    main()