from app import init_csv_files

if __name__ == '__main__':
    init_csv_files()
    print('CSV inited')
