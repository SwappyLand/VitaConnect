from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from db_config import (Database, RestaurantOperations, CustomerOperations, 
                       MenuOperations, OrderOperations, ReservationOperations,
                       InventoryOperations, StaffOperations, AnalyticsOperations)
from datetime import datetime
import json
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from io import BytesIO

app = Flask(__name__)
app.secret_key = 'your_secret_key_here_change_in_production'

# Template filter for timedelta formatting
@app.template_filter('format_time')
def format_time(td):
    """Convert timedelta to HH:MM format"""
    if td is None:
        return 'N/A'
    if isinstance(td, str):
        return td
    # timedelta to time string
    total_seconds = int(td.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    return f"{hours:02d}:{minutes:02d}"

@app.template_filter('format_datetime')
def format_datetime(dt):
    """Format datetime object"""
    if dt is None:
        return 'N/A'
    if hasattr(dt, 'strftime'):
        return dt.strftime('%Y-%m-%d %H:%M')
    return str(dt)

@app.template_filter('format_date')
def format_date(d):
    """Format date object"""
    if d is None:
        return 'N/A'
    if hasattr(d, 'strftime'):
        return d.strftime('%Y-%m-%d')
    return str(d)

# Initialize database
db = Database()
db.connect()

# Initialize operations
restaurant_ops = RestaurantOperations(db)
customer_ops = CustomerOperations(db)
menu_ops = MenuOperations(db)
order_ops = OrderOperations(db)
reservation_ops = ReservationOperations(db)
inventory_ops = InventoryOperations(db)
staff_ops = StaffOperations(db)
analytics_ops = AnalyticsOperations(db)


@app.route('/')
def index():
    """Dashboard home page"""
    restaurants = restaurant_ops.get_all_restaurants()
    revenue_data = analytics_ops.get_revenue_by_restaurant()
    low_stock = inventory_ops.get_low_stock_items()
    recent_orders = order_ops.get_all_orders()[:5]
    
    return render_template('index.html', 
                         restaurants=restaurants,
                         revenue_data=revenue_data,
                         low_stock=low_stock,
                         recent_orders=recent_orders)


@app.route('/restaurants')
def restaurants():
    """View all restaurants"""
    all_restaurants = restaurant_ops.get_all_restaurants()
    return render_template('restaurants.html', restaurants=all_restaurants)


@app.route('/restaurant/add', methods=['GET', 'POST'])
def add_restaurant():
    """Add new restaurant"""
    if request.method == 'POST':
        name = request.form['name']
        location = request.form['location']
        phone = request.form['phone']
        opening_time = request.form['opening_time']
        closing_time = request.form['closing_time']
        
        restaurant_id = restaurant_ops.add_restaurant(name, location, phone, 
                                                     opening_time, closing_time)
        if restaurant_id:
            flash('Restaurant added successfully!', 'success')
            return redirect(url_for('restaurants'))
        else:
            flash('Error adding restaurant', 'error')
    
    return render_template('add_restaurant.html')


@app.route('/customers')
def customers():
    """View all customers"""
    all_customers = customer_ops.get_all_customers()
    return render_template('customers.html', customers=all_customers)


@app.route('/customer/add', methods=['GET', 'POST'])
def add_customer():
    """Add new customer"""
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        
        customer_id = customer_ops.add_customer(name, email, phone, address)
        if customer_id:
            flash('Customer added successfully!', 'success')
            return redirect(url_for('customers'))
        else:
            flash('Error adding customer', 'error')
    
    return render_template('add_customer.html')


@app.route('/menu')
def menu():
    """View menu items"""
    restaurant_id = request.args.get('restaurant_id')
    menu_items = menu_ops.get_menu_items(restaurant_id)
    restaurants = restaurant_ops.get_all_restaurants()
    return render_template('menu.html', menu_items=menu_items, restaurants=restaurants)


@app.route('/menu/add', methods=['GET', 'POST'])
def add_menu_item():
    """Add new menu item"""
    if request.method == 'POST':
        restaurant_id = request.form['restaurant_id']
        name = request.form['name']
        description = request.form['description']
        category = request.form['category']
        price = request.form['price']
        
        item_id = menu_ops.add_menu_item(restaurant_id, name, description, category, price)
        if item_id:
            flash('Menu item added successfully!', 'success')
            return redirect(url_for('menu'))
        else:
            flash('Error adding menu item', 'error')
    
    restaurants = restaurant_ops.get_all_restaurants()
    return render_template('add_menu_item.html', restaurants=restaurants)


@app.route('/orders')
def orders():
    """View all orders"""
    all_orders = order_ops.get_all_orders()
    return render_template('orders.html', orders=all_orders)


@app.route('/order/<int:order_id>')
def order_details(order_id):
    """View order details"""
    order = order_ops.get_order(order_id)
    order_items = order_ops.get_order_items(order_id)
    return render_template('order_details.html', order=order, order_items=order_items)


@app.route('/order/create', methods=['GET', 'POST'])
def create_order():
    """Create new order"""
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        restaurant_id = request.form['restaurant_id']
        order_type = request.form['order_type']
        payment_method = request.form['payment_method']
        items = request.form.getlist('item_id[]')
        quantities = request.form.getlist('quantity[]')
        prices = request.form.getlist('price[]')
        
        # Create order
        order_id = order_ops.create_order(customer_id, restaurant_id, order_type)
        
        if order_id:
            # Add order items
            for item_id, quantity, price in zip(items, quantities, prices):
                if item_id and quantity:
                    order_ops.add_order_item(order_id, item_id, int(quantity), float(price))
            
            # Update total
            order_ops.update_order_total(order_id)
            
            # Get the total amount
            order = order_ops.get_order(order_id)
            
            # Add payment
            order_ops.add_payment(order_id, payment_method, order['total_amount'])
            
            flash('Order created successfully!', 'success')
            return redirect(url_for('order_details', order_id=order_id))
        else:
            flash('Error creating order', 'error')
    
    customers = customer_ops.get_all_customers()
    restaurants = restaurant_ops.get_all_restaurants()
    return render_template('create_order.html', customers=customers, restaurants=restaurants)


@app.route('/order/update_status/<int:order_id>', methods=['POST'])
def update_order_status(order_id):
    """Update order status"""
    status = request.form['status']
    if order_ops.update_order_status(order_id, status):
        flash('Order status updated!', 'success')
    else:
        flash('Error updating order status', 'error')
    return redirect(url_for('order_details', order_id=order_id))


@app.route('/reservations')
def reservations():
    """View all reservations"""
    all_reservations = reservation_ops.get_all_reservations()
    return render_template('reservations.html', reservations=all_reservations)


@app.route('/reservation/add', methods=['GET', 'POST'])
def add_reservation():
    """Add new reservation"""
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        restaurant_id = request.form['restaurant_id']
        table_number = request.form['table_number']
        reservation_date = request.form['reservation_date']
        reservation_time = request.form['reservation_time']
        party_size = request.form['party_size']
        
        reservation_id = reservation_ops.add_reservation(customer_id, restaurant_id, 
                                                        table_number, reservation_date,
                                                        reservation_time, party_size)
        if reservation_id:
            flash('Reservation added successfully!', 'success')
            return redirect(url_for('reservations'))
        else:
            flash('Error adding reservation', 'error')
    
    customers = customer_ops.get_all_customers()
    restaurants = restaurant_ops.get_all_restaurants()
    return render_template('add_reservation.html', customers=customers, restaurants=restaurants)


@app.route('/reservation/update_status/<int:reservation_id>', methods=['POST'])
def update_reservation_status(reservation_id):
    """Update reservation status"""
    status = request.form['status']
    if reservation_ops.update_reservation_status(reservation_id, status):
        flash('Reservation status updated!', 'success')
    else:
        flash('Error updating reservation status', 'error')
    return redirect(url_for('reservations'))


@app.route('/inventory')
def inventory():
    """View inventory"""
    restaurant_id = request.args.get('restaurant_id')
    items = inventory_ops.get_inventory(restaurant_id)
    restaurants = restaurant_ops.get_all_restaurants()
    low_stock = inventory_ops.get_low_stock_items()
    return render_template('inventory.html', items=items, restaurants=restaurants, 
                         low_stock=low_stock)


@app.route('/inventory/edit/<int:inventory_id>', methods=['GET', 'POST'])
def edit_inventory(inventory_id):
    """Edit inventory item"""
    if request.method == 'POST':
        quantity = request.form['quantity']
        reorder_level = request.form['reorder_level']
        last_restocked = request.form['last_restocked']
        
        if inventory_ops.update_inventory(inventory_id, quantity, reorder_level, last_restocked):
            flash('Inventory updated successfully!', 'success')
            return redirect(url_for('inventory'))
        else:
            flash('Error updating inventory', 'error')
    
    item = inventory_ops.get_inventory_item(inventory_id)
    return render_template('edit_inventory.html', item=item)


@app.route('/inventory/add', methods=['GET', 'POST'])
def add_inventory():
    """Add new inventory item"""
    if request.method == 'POST':
        restaurant_id = request.form['restaurant_id']
        supplier_id = request.form.get('supplier_id') or None
        item_name = request.form['item_name']
        quantity = request.form['quantity']
        unit = request.form['unit']
        reorder_level = request.form['reorder_level']
        last_restocked = request.form['last_restocked']
        
        if inventory_ops.add_inventory_item(restaurant_id, supplier_id, item_name, 
                                           quantity, unit, reorder_level, last_restocked):
            flash('Inventory item added successfully!', 'success')
            return redirect(url_for('inventory'))
        else:
            flash('Error adding inventory item', 'error')
    
    restaurants = restaurant_ops.get_all_restaurants()
    suppliers = db.fetch_all("SELECT * FROM Supplier")
    return render_template('add_inventory.html', restaurants=restaurants, suppliers=suppliers)


@app.route('/staff')
def staff():
    """View all staff"""
    all_staff = staff_ops.get_all_staff()
    return render_template('staff.html', staff=all_staff)


@app.route('/staff/add', methods=['GET', 'POST'])
def add_staff():
    """Add new staff member"""
    if request.method == 'POST':
        restaurant_id = request.form['restaurant_id']
        name = request.form['name']
        role = request.form['role']
        phone = request.form['phone']
        salary = request.form['salary']
        hire_date = request.form['hire_date']
        
        staff_id = staff_ops.add_staff(restaurant_id, name, role, phone, salary, hire_date)
        if staff_id:
            flash('Staff member added successfully!', 'success')
            return redirect(url_for('staff'))
        else:
            flash('Error adding staff member', 'error')
    
    restaurants = restaurant_ops.get_all_restaurants()
    return render_template('add_staff.html', restaurants=restaurants)


@app.route('/analytics')
def analytics():
    """View analytics dashboard"""
    revenue_data = analytics_ops.get_revenue_by_restaurant()
    popular_items = analytics_ops.get_popular_items(10)
    return render_template('analytics.html', revenue_data=revenue_data, 
                         popular_items=popular_items)


@app.route('/api/menu/<int:restaurant_id>')
def api_get_menu(restaurant_id):
    """API endpoint to get menu items for a restaurant"""
    menu_items = menu_ops.get_menu_items(restaurant_id)
    return jsonify(menu_items)


@app.route('/api/customer/<int:customer_id>/orders')
def api_customer_orders(customer_id):
    """API endpoint to get customer order history"""
    orders = analytics_ops.get_customer_order_history(customer_id)
    return jsonify(orders)


@app.route('/order/<int:order_id>/bill')
def generate_bill(order_id):
    """Generate PDF bill for order"""
    order = order_ops.get_order(order_id)
    order_items = order_ops.get_order_items(order_id)
    
    if not order:
        flash('Order not found', 'error')
        return redirect(url_for('orders'))
    
    # Create PDF in memory
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []
    
    # Styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#667eea'),
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#333333'),
        spaceAfter=12
    )
    
    # Title
    title = Paragraph(f"<b>{order['restaurant_name']}</b>", title_style)
    elements.append(title)
    
    # Restaurant details
    restaurant_info = Paragraph(
        f"{order['restaurant_location']}<br/>"
        f"Phone: {order['restaurant_phone']}<br/>"
        f"<br/><b>INVOICE</b>",
        styles['Normal']
    )
    elements.append(restaurant_info)
    elements.append(Spacer(1, 20))
    
    # Order details
    order_date = order['order_date'].strftime('%Y-%m-%d %H:%M') if order['order_date'] else 'N/A'
    
    order_info_data = [
        ['Order ID:', f"#{order['order_id']}", 'Date:', order_date],
        ['Customer:', order['customer_name'], 'Phone:', order['customer_phone']],
        ['Order Type:', order['order_type'].upper(), 'Payment:', order.get('payment_method', 'N/A').upper()]
    ]
    
    order_info_table = Table(order_info_data, colWidths=[1.5*inch, 2*inch, 1.2*inch, 2*inch])
    order_info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
    ]))
    elements.append(order_info_table)
    elements.append(Spacer(1, 20))
    
    # Order items table
    items_heading = Paragraph("<b>Order Items</b>", heading_style)
    elements.append(items_heading)
    
    items_data = [['Item', 'Quantity', 'Price', 'Subtotal']]
    for item in order_items:
        items_data.append([
            item['item_name'],
            str(item['quantity']),
            f"₹{item['price']:.2f}",
            f"₹{item['subtotal']:.2f}"
        ])
    
    items_table = Table(items_data, colWidths=[3.5*inch, 1*inch, 1.2*inch, 1.2*inch])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#667eea')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
    ]))
    elements.append(items_table)
    elements.append(Spacer(1, 20))
    
    # Total
    total_data = [
        ['', '', 'Total Amount:', f"₹{order['total_amount']:.2f}"]
    ]
    total_table = Table(total_data, colWidths=[3.5*inch, 1*inch, 1.2*inch, 1.2*inch])
    total_table.setStyle(TableStyle([
        ('FONTNAME', (2, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (2, 0), (-1, 0), 14),
        ('ALIGN', (2, 0), (-1, 0), 'CENTER'),
        ('BACKGROUND', (2, 0), (-1, 0), colors.HexColor('#f0f0f0')),
        ('BOX', (2, 0), (-1, 0), 2, colors.black)
    ]))
    elements.append(total_table)
    elements.append(Spacer(1, 30))
    
    # Footer
    footer = Paragraph(
        "<b>Thank you for dining with us!</b><br/>"
        "Please visit again.",
        ParagraphStyle('Footer', parent=styles['Normal'], alignment=TA_CENTER)
    )
    elements.append(footer)
    
    # Build PDF
    doc.build(elements)
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'bill_order_{order_id}.pdf',
        mimetype='application/pdf'
    )


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)