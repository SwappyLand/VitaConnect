import mysql.connector
from mysql.connector import Error

class Database:
    """Database connection handler for Restaurant Management System"""
    
    def __init__(self):
        self.host = "localhost"
        self.user = "root"
        self.password = "HarshvShah"
        self.database = "restaurant_management"
        self.connection = None
    
    def connect(self):
        """Establish database connection"""
        try:
            self.connection = mysql.connector.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database
            )
            if self.connection.is_connected():
                print("Successfully connected to MySQL database")
                return self.connection
        except Error as e:
            print(f"Error connecting to MySQL: {e}")
            return None
    
    def disconnect(self):
        """Close database connection"""
        if self.connection and self.connection.is_connected():
            self.connection.close()
            print("MySQL connection closed")
    
    def execute_query(self, query, params=None):
        """Execute INSERT, UPDATE, DELETE queries"""
        cursor = self.connection.cursor()
        try:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            self.connection.commit()
            return cursor.lastrowid
        except Error as e:
            print(f"Error executing query: {e}")
            self.connection.rollback()
            return None
        finally:
            cursor.close()
    
    def fetch_all(self, query, params=None):
        """Execute SELECT query and fetch all results"""
        cursor = self.connection.cursor(dictionary=True)
        try:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            results = cursor.fetchall()
            return results
        except Error as e:
            print(f"Error fetching data: {e}")
            return []
        finally:
            cursor.close()
    
    def fetch_one(self, query, params=None):
        """Execute SELECT query and fetch one result"""
        cursor = self.connection.cursor(dictionary=True)
        try:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            result = cursor.fetchone()
            return result
        except Error as e:
            print(f"Error fetching data: {e}")
            return None
        finally:
            cursor.close()


# Database operations for each entity
class RestaurantOperations:
    def __init__(self, db):
        self.db = db
    
    def get_all_restaurants(self):
        query = "SELECT * FROM Restaurant ORDER BY rating DESC"
        return self.db.fetch_all(query)
    
    def get_restaurant(self, restaurant_id):
        query = "SELECT * FROM Restaurant WHERE restaurant_id = %s"
        return self.db.fetch_one(query, (restaurant_id,))
    
    def add_restaurant(self, name, location, phone, opening_time, closing_time):
        query = """INSERT INTO Restaurant (name, location, phone, opening_time, closing_time) 
                   VALUES (%s, %s, %s, %s, %s)"""
        return self.db.execute_query(query, (name, location, phone, opening_time, closing_time))


class CustomerOperations:
    def __init__(self, db):
        self.db = db
    
    def get_all_customers(self):
        query = "SELECT * FROM Customer ORDER BY created_at DESC"
        return self.db.fetch_all(query)
    
    def get_customer(self, customer_id):
        query = "SELECT * FROM Customer WHERE customer_id = %s"
        return self.db.fetch_one(query, (customer_id,))
    
    def add_customer(self, name, email, phone, address):
        query = """INSERT INTO Customer (name, email, phone, address) 
                   VALUES (%s, %s, %s, %s)"""
        return self.db.execute_query(query, (name, email, phone, address))


class MenuOperations:
    def __init__(self, db):
        self.db = db
    
    def get_menu_items(self, restaurant_id=None):
        if restaurant_id:
            query = """SELECT m.*, r.name as restaurant_name 
                      FROM Menu_Item m 
                      JOIN Restaurant r ON m.restaurant_id = r.restaurant_id 
                      WHERE m.restaurant_id = %s AND m.availability = TRUE"""
            return self.db.fetch_all(query, (restaurant_id,))
        else:
            query = """SELECT m.*, r.name as restaurant_name 
                      FROM Menu_Item m 
                      JOIN Restaurant r ON m.restaurant_id = r.restaurant_id 
                      WHERE m.availability = TRUE"""
            return self.db.fetch_all(query)
    
    def add_menu_item(self, restaurant_id, name, description, category, price):
        query = """INSERT INTO Menu_Item (restaurant_id, name, description, category, price) 
                   VALUES (%s, %s, %s, %s, %s)"""
        return self.db.execute_query(query, (restaurant_id, name, description, category, price))


class OrderOperations:
    def __init__(self, db):
        self.db = db
    
    def get_all_orders(self):
        query = "SELECT * FROM order_details ORDER BY order_date DESC"
        return self.db.fetch_all(query)
    
    def get_order(self, order_id):
        query = """SELECT o.*, c.name as customer_name, c.phone as customer_phone,
                   c.address as customer_address, r.name as restaurant_name,
                   r.location as restaurant_location, r.phone as restaurant_phone,
                   p.payment_method, p.status as payment_status
                   FROM Orders o
                   JOIN Customer c ON o.customer_id = c.customer_id
                   JOIN Restaurant r ON o.restaurant_id = r.restaurant_id
                   LEFT JOIN Payment p ON o.order_id = p.order_id
                   WHERE o.order_id = %s"""
        return self.db.fetch_one(query, (order_id,))
    
    def get_order_items(self, order_id):
        query = """SELECT oi.*, m.name as item_name 
                   FROM Order_Item oi
                   JOIN Menu_Item m ON oi.item_id = m.item_id
                   WHERE oi.order_id = %s"""
        return self.db.fetch_all(query, (order_id,))
    
    def create_order(self, customer_id, restaurant_id, order_type):
        query = """INSERT INTO Orders (customer_id, restaurant_id, order_type) 
                   VALUES (%s, %s, %s)"""
        return self.db.execute_query(query, (customer_id, restaurant_id, order_type))
    
    def add_order_item(self, order_id, item_id, quantity, price):
        query = """INSERT INTO Order_Item (order_id, item_id, quantity, price) 
                   VALUES (%s, %s, %s, %s)"""
        return self.db.execute_query(query, (order_id, item_id, quantity, price))
    
    def update_order_total(self, order_id):
        query = """UPDATE Orders SET total_amount = (
                   SELECT SUM(subtotal) FROM Order_Item WHERE order_id = %s
                   ) WHERE order_id = %s"""
        return self.db.execute_query(query, (order_id, order_id))
    
    def update_order_status(self, order_id, status):
        query = "UPDATE Orders SET status = %s WHERE order_id = %s"
        return self.db.execute_query(query, (status, order_id))
    
    def add_payment(self, order_id, payment_method, amount):
        query = """INSERT INTO Payment (order_id, payment_method, amount, status)
                   VALUES (%s, %s, %s, 'completed')"""
        return self.db.execute_query(query, (order_id, payment_method, amount))


class ReservationOperations:
    def __init__(self, db):
        self.db = db
    
    def get_all_reservations(self):
        query = """SELECT tr.*, c.name as customer_name, r.name as restaurant_name
                   FROM Table_Reservation tr
                   JOIN Customer c ON tr.customer_id = c.customer_id
                   JOIN Restaurant r ON tr.restaurant_id = r.restaurant_id
                   ORDER BY tr.reservation_date DESC, tr.reservation_time DESC"""
        return self.db.fetch_all(query)
    
    def add_reservation(self, customer_id, restaurant_id, table_number, 
                       reservation_date, reservation_time, party_size):
        query = """INSERT INTO Table_Reservation 
                   (customer_id, restaurant_id, table_number, reservation_date, 
                    reservation_time, party_size) 
                   VALUES (%s, %s, %s, %s, %s, %s)"""
        return self.db.execute_query(query, (customer_id, restaurant_id, table_number,
                                             reservation_date, reservation_time, party_size))
    
    def update_reservation_status(self, reservation_id, status):
        query = "UPDATE Table_Reservation SET status = %s WHERE reservation_id = %s"
        return self.db.execute_query(query, (status, reservation_id))


class InventoryOperations:
    def __init__(self, db):
        self.db = db
    
    def get_inventory(self, restaurant_id=None):
        if restaurant_id:
            query = """SELECT i.*, r.name as restaurant_name, s.name as supplier_name
                      FROM Inventory i
                      JOIN Restaurant r ON i.restaurant_id = r.restaurant_id
                      LEFT JOIN Supplier s ON i.supplier_id = s.supplier_id
                      WHERE i.restaurant_id = %s"""
            return self.db.fetch_all(query, (restaurant_id,))
        else:
            query = """SELECT i.*, r.name as restaurant_name, s.name as supplier_name
                      FROM Inventory i
                      JOIN Restaurant r ON i.restaurant_id = r.restaurant_id
                      LEFT JOIN Supplier s ON i.supplier_id = s.supplier_id"""
            return self.db.fetch_all(query)
    
    def get_low_stock_items(self):
        query = """SELECT i.*, r.name as restaurant_name
                   FROM Inventory i
                   JOIN Restaurant r ON i.restaurant_id = r.restaurant_id
                   WHERE i.quantity <= i.reorder_level"""
        return self.db.fetch_all(query)
    
    def get_inventory_item(self, inventory_id):
        query = """SELECT i.*, r.name as restaurant_name, s.name as supplier_name
                   FROM Inventory i
                   JOIN Restaurant r ON i.restaurant_id = r.restaurant_id
                   LEFT JOIN Supplier s ON i.supplier_id = s.supplier_id
                   WHERE i.inventory_id = %s"""
        return self.db.fetch_one(query, (inventory_id,))
    
    def update_inventory(self, inventory_id, quantity, reorder_level, last_restocked):
        query = """UPDATE Inventory 
                   SET quantity = %s, reorder_level = %s, last_restocked = %s
                   WHERE inventory_id = %s"""
        return self.db.execute_query(query, (quantity, reorder_level, last_restocked, inventory_id))
    
    def add_inventory_item(self, restaurant_id, supplier_id, item_name, quantity, unit, reorder_level, last_restocked):
        query = """INSERT INTO Inventory 
                   (restaurant_id, supplier_id, item_name, quantity, unit, reorder_level, last_restocked)
                   VALUES (%s, %s, %s, %s, %s, %s, %s)"""
        return self.db.execute_query(query, (restaurant_id, supplier_id, item_name, quantity, 
                                             unit, reorder_level, last_restocked))


class StaffOperations:
    def __init__(self, db):
        self.db = db
    
    def get_all_staff(self):
        query = """SELECT s.*, r.name as restaurant_name
                   FROM Staff s
                   JOIN Restaurant r ON s.restaurant_id = r.restaurant_id
                   ORDER BY s.restaurant_id, s.role"""
        return self.db.fetch_all(query)
    
    def add_staff(self, restaurant_id, name, role, phone, salary, hire_date):
        query = """INSERT INTO Staff (restaurant_id, name, role, phone, salary, hire_date)
                   VALUES (%s, %s, %s, %s, %s, %s)"""
        return self.db.execute_query(query, (restaurant_id, name, role, phone, salary, hire_date))


class AnalyticsOperations:
    def __init__(self, db):
        self.db = db
    
    def get_revenue_by_restaurant(self):
        query = "SELECT * FROM revenue_by_restaurant"
        return self.db.fetch_all(query)
    
    def get_popular_items(self, limit=10):
        query = """SELECT m.name, m.category, m.price, r.name as restaurant_name,
                   COUNT(oi.order_item_id) as times_ordered,
                   SUM(oi.subtotal) as total_revenue
                   FROM Menu_Item m
                   JOIN Order_Item oi ON m.item_id = oi.item_id
                   JOIN Restaurant r ON m.restaurant_id = r.restaurant_id
                   GROUP BY m.item_id
                   ORDER BY times_ordered DESC
                   LIMIT %s"""
        return self.db.fetch_all(query, (limit,))
    
    def get_customer_order_history(self, customer_id):
        query = """SELECT o.order_id, o.order_date, o.order_type, o.status,
                   o.total_amount, r.name as restaurant_name
                   FROM Orders o
                   JOIN Restaurant r ON o.restaurant_id = r.restaurant_id
                   WHERE o.customer_id = %s
                   ORDER BY o.order_date DESC"""
        return self.db.fetch_all(query, (customer_id,))