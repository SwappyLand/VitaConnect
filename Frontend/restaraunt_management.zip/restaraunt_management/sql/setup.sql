-- ===========================
-- 1️⃣ TRIGGER: Update Restaurant Revenue After New Order
-- ===========================
DELIMITER //
CREATE TRIGGER after_order_insert
AFTER INSERT ON orders
FOR EACH ROW
BEGIN
    UPDATE restaurant
    SET total_revenue = IFNULL(total_revenue, 0) + NEW.total_amount
    WHERE restaurant_id = NEW.restaurant_id;
END;
//
DELIMITER ;

-- ===========================
-- 2️⃣ FUNCTION: Calculate Total Amount of an Order
-- ===========================
DELIMITER //
CREATE FUNCTION get_order_total(p_order_id INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE total DECIMAL(10,2);
    SELECT SUM(oi.quantity * mi.price)
    INTO total
    FROM order_item oi
    JOIN menu_item mi ON oi.item_id = mi.item_id
    WHERE oi.order_id = p_order_id;
    RETURN IFNULL(total, 0.00);
END;
//
DELIMITER ;

-- ===========================
-- 3️⃣ STORED PROCEDURE: Place New Order
-- ===========================
DELIMITER //
CREATE PROCEDURE place_order(
    IN p_customer_id INT,
    IN p_restaurant_id INT,
    IN p_order_type VARCHAR(20)
)
BEGIN
    DECLARE v_order_id INT;

    -- Insert order
    INSERT INTO orders (customer_id, restaurant_id, order_type, order_date, total_amount, status)
    VALUES (p_customer_id, p_restaurant_id, p_order_type, NOW(), 0, 'Pending');

    SET v_order_id = LAST_INSERT_ID();

    -- You can later insert items into order_item and then update total
    UPDATE orders
    SET total_amount = get_order_total(v_order_id)
    WHERE order_id = v_order_id;

    SELECT v_order_id AS 'New_Order_ID';
END;
//
DELIMITER ;

-- ===========================
-- 4️⃣ CURSOR: Calculate Average Menu Price per Restaurant
-- ===========================
DELIMITER //
CREATE PROCEDURE avg_menu_price()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE r_id INT;
    DECLARE avg_price DECIMAL(10,2);
    DECLARE cur CURSOR FOR SELECT DISTINCT restaurant_id FROM menu_item;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO r_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SELECT AVG(price) INTO avg_price
        FROM menu_item
        WHERE restaurant_id = r_id;

        UPDATE restaurant
        SET avg_item_price = avg_price
        WHERE restaurant_id = r_id;
    END LOOP;
    CLOSE cur;
END;
//
DELIMITER ;


-- Restaurant Management System - Full SQL (40+ records per table)
DROP DATABASE IF EXISTS restaurant_management;
CREATE DATABASE restaurant_management;
USE restaurant_management;

-- Customer Table
CREATE TABLE Customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Restaurant Table
CREATE TABLE Restaurant (
    restaurant_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(200) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    opening_time TIME,
    closing_time TIME,
    rating DECIMAL(3,2) DEFAULT 0.00
);

-- Staff Table
CREATE TABLE Staff (
    staff_id INT PRIMARY KEY AUTO_INCREMENT,
    restaurant_id INT,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    salary DECIMAL(10,2),
    hire_date DATE,
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(restaurant_id) ON DELETE CASCADE
);

-- Supplier Table
CREATE TABLE Supplier (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    address TEXT
);

-- Inventory Table
CREATE TABLE Inventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    restaurant_id INT,
    supplier_id INT,
    item_name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    unit VARCHAR(20),
    reorder_level INT DEFAULT 10,
    last_restocked DATE,
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(restaurant_id) ON DELETE CASCADE,
    FOREIGN KEY (supplier_id) REFERENCES Supplier(supplier_id) ON DELETE SET NULL
);

-- Menu Item Table
CREATE TABLE Menu_Item (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    restaurant_id INT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    availability BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(restaurant_id) ON DELETE CASCADE
);

-- Table Reservation Table
CREATE TABLE Table_Reservation (
    reservation_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    restaurant_id INT,
    table_number INT NOT NULL,
    reservation_date DATE NOT NULL,
    reservation_time TIME NOT NULL,
    party_size INT NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(restaurant_id) ON DELETE CASCADE
);

-- Orders Table
CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    restaurant_id INT,
    order_type ENUM('dine-in', 'delivery', 'takeaway') NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'preparing', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    total_amount DECIMAL(10,2) DEFAULT 0.00,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(restaurant_id) ON DELETE CASCADE
);

-- Order Item Table
CREATE TABLE Order_Item (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    item_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) GENERATED ALWAYS AS (quantity * price) STORED,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES Menu_Item(item_id) ON DELETE CASCADE
);

-- Payment Table
CREATE TABLE Payment (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    payment_method ENUM('cash', 'card', 'upi', 'wallet') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE
);

-- Delivery Agent Table
CREATE TABLE Delivery_Agent (
    agent_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    vehicle_type VARCHAR(50),
    availability BOOLEAN DEFAULT TRUE,
    rating DECIMAL(3,2) DEFAULT 0.00
);

-- Delivery Table
CREATE TABLE Delivery (
    delivery_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    agent_id INT,
    pickup_time TIMESTAMP NULL,
    delivery_time TIMESTAMP NULL,
    delivery_address TEXT NOT NULL,
    status ENUM('assigned', 'picked_up', 'in_transit', 'delivered', 'cancelled') DEFAULT 'assigned',
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES Delivery_Agent(agent_id) ON DELETE SET NULL
);

-- -------------------------
-- INSERTS (40+ records each)
-- -------------------------

-- Restaurants (40 restaurants - ALL PURE VEG)
INSERT INTO Restaurant (name, location, phone, opening_time, closing_time, rating) VALUES
('GreenLeaf Veg Bistro','MG Road, Pune','9123000001','08:00:00','23:00:00',4.6),
('Shuddh Swaad','FC Road, Pune','9123000002','09:00:00','22:30:00',4.5),
('Sattvik Delights','Baner, Pune','9123000003','08:30:00','22:00:00',4.4),
('Veggie Junction','Kothrud, Pune','9123000004','10:00:00','23:00:00',4.3),
('The Vegetarian House','Happy Street, Pune','9123000005','09:00:00','22:00:00',4.7),
('Dharma Bhojan','Camp, Pune','9123000006','07:30:00','21:30:00',4.2),
('Shakahari Bhojanalay','Aundh, Pune','9123000007','08:00:00','22:30:00',4.5),
('Pure Veg Corner','Baner Pashan Link Rd','9123000008','09:00:00','23:30:00',4.4),
('Annapurna Family Dhaba','Sinhagad Rd, Pune','9123000009','06:00:00','23:00:00',4.1),
('Urban Tiffins','Deccan Gymkhana, Pune','9123000010','08:00:00','21:00:00',4.3),
('Hariyali Restaurant','Wakad, Pune','9123000011','09:30:00','22:00:00',4.2),
('Gaon Ki Rasoi','Hinjewadi, Pune','9123000012','07:00:00','22:30:00',4.0),
('Shree Vegetarian','Kalyani Nagar, Pune','9123000013','10:00:00','23:00:00',4.6),
('Sattvik Ras','Viman Nagar, Pune','9123000014','08:00:00','22:00:00',4.4),
('Ruchi Veg Kitchen','Pimple Saudagar, Pune','9123000015','09:00:00','22:30:00',4.3),
('Khandani Bhoj','Sadashiv Peth, Pune','9123000016','11:00:00','23:00:00',4.2),
('Madhur Milan Veg','Camp Road, Pune','9123000017','08:30:00','22:30:00',4.1),
('Herbal Spoon','Wadgaon Sheri, Pune','9123000018','09:00:00','22:00:00',4.0),
('Prana Veg','Koregaon Park, Pune','9123000019','10:00:00','23:00:00',4.7),
('Sattvik Sippers','FC Road Extension, Pune','9123000020','07:00:00','21:30:00',4.2),
('Veggie Villa','Vile Parle East, Mumbai','9123000021','08:00:00','23:00:00',4.6),
('Shuddh Bhojan','Bandra West, Mumbai','9123000022','09:00:00','22:30:00',4.5),
('Green Curry House','Andheri West, Mumbai','9123000023','10:00:00','23:00:00',4.4),
('Satvik Spice','Juhu, Mumbai','9123000024','11:00:00','23:30:00',4.3),
('Ritual Veg','Dadar, Mumbai','9123000025','07:00:00','22:00:00',4.5),
('Veg Mantra','Powai, Mumbai','9123000026','12:00:00','23:00:00',4.4),
('Sattvic Bites','Colaba, Mumbai','9123000027','09:00:00','00:00:00',4.5),
('Purely Veg Cafe','Fort, Mumbai','9123000028','10:00:00','22:30:00',4.6),
('Tiffin Tale','Malad, Mumbai','9123000029','18:00:00','23:30:00',4.2),
('The Green Thali','Lower Parel, Mumbai','9123000030','12:00:00','23:00:00',4.4),
('Palak & Co','Goregaon, Mumbai','9123000031','11:00:00','23:30:00',4.3),
('Biryani Veg House','Thane, Mumbai','9123000032','11:00:00','23:00:00',4.4),
('Dessert Greens','Worli, Mumbai','9123000033','10:00:00','22:00:00',4.7),
('Sattvik Grill','Kothrud West, Pune','9123000034','08:00:00','22:00:00',4.3),
('Veggie Express','Pune Station Area','9123000035','09:00:00','23:00:00',4.2),
('Anand Bhojan','Shivaji Nagar, Pune','9123000036','08:30:00','22:30:00',4.1),
('Sanskriti Veg','Navi Mumbai, CBD','9123000037','09:00:00','23:00:00',4.2),
('Shakahari Magic','Khar West, Mumbai','9123000038','10:00:00','23:00:00',4.3),
('Satvik Sweets','Dombivli, Mumbai','9123000039','07:30:00','21:30:00',4.1),
('Veg Tantra','Vasai, Mumbai','9123000040','09:00:00','22:00:00',4.0);

-- Customers (40 customers)
INSERT INTO Customer (name, email, phone, address) VALUES
('Rahul Sharma','rahul.sharma1@example.com','9000000001','Flat 101, Shanti Nagar, Pune'),
('Priya Patel','priya.patel1@example.com','9000000002','House 12, Baner, Pune'),
('Amit Kumar','amit.kumar1@example.com','9000000003','House 45, Kothrud, Pune'),
('Sneha Reddy','sneha.reddy1@example.com','9000000004','Apartment 5B, Viman Nagar, Pune'),
('Vikram Singh','vikram.singh1@example.com','9000000005','Tower 2, Aundh, Pune'),
('Anjali Verma','anjali.verma1@example.com','9000000006','Flat 12, Wakad, Pune'),
('Ravi Nair','ravi.nair1@example.com','9000000007','Building C, Hinjewadi, Pune'),
('Neha Joshi','neha.joshi1@example.com','9000000008','House 45, Thane, Mumbai'),
('Karan Mehta','karan.mehta1@example.com','9000000009','Flat 201, Worli, Mumbai'),
('Pooja Desai','pooja.desai1@example.com','9000000010','Tower A, Lower Parel, Mumbai'),
('Sanjay Gupta','sanjay.gupta1@example.com','9000000011','House 67, Juhu, Mumbai'),
('Divya Shah','divya.shah1@example.com','9000000012','Flat 8, Colaba, Mumbai'),
('Arjun Rao','arjun.rao1@example.com','9000000013','Building B, Dadar, Mumbai'),
('Meera Iyer','meera.iyer1@example.com','9000000014','Apartment 3C, Fort, Mumbai'),
('Rohan Kapoor','rohan.kapoor1@example.com','9000000015','Tower 5, Linking Road, Mumbai'),
('Kavita Pillai','kavita.pillai1@example.com','9000000016','House 89, Churchgate, Mumbai'),
('Suresh Menon','suresh.menon1@example.com','9000000017','Flat 15, MG Road, Pune'),
('Lakshmi Krishnan','lakshmi.krishnan1@example.com','9000000018','Building D, Bandra West, Mumbai'),
('Rajesh Agarwal','rajesh.agarwal1@example.com','9000000019','Apartment 9A, Andheri East, Mumbai'),
('Deepika Shetty','deepika.shetty1@example.com','9000000020','Tower 3, Goregaon, Mumbai'),
('Harsh Shah','harsh.shah@example.com','9000000021','MIT Campus, Kothrud, Pune'),
('Riya Patel','riya.patel2@example.com','9000000022','Vadodara Street, Vadodara'),
('Kunal Joshi','kunal.joshi@example.com','9000000023','Sector 12, Navi Mumbai'),
('Nisha Rao','nisha.rao@example.com','9000000024','Lane 7, Pimpri, Pune'),
('Sagar Deshmukh','sagar.d@example.com','9000000025','MG Road Residences, Pune'),
('Tanvi More','tanvi.more@example.com','9000000026','Hill View, Thane'),
('Manish P','manish.p@example.com','9000000027','Lake Side, Navi Mumbai'),
('Sheetal K','sheetal.k@example.com','9000000028','Sector 5, Kalyan'),
('Vivek A','vivek.a@example.com','9000000029','Bandra East, Mumbai'),
('Mehul D','mehul.d@example.com','9000000030','Goregaon East, Mumbai'),
('Pankaj R','pankaj.r@example.com','9000000031','Kharghar, Navi Mumbai'),
('Alka S','alka.s@example.com','9000000032','Dombivli West, Mumbai'),
('Ritika M','ritika.m@example.com','9000000033','Chembur, Mumbai'),
('Yash T','yash.t@example.com','9000000034','Vasai East, Mumbai'),
('Isha B','isha.b@example.com','9000000035','Thane West, Thane'),
('Nitin G','nitin.g@example.com','9000000036','Khar Road, Mumbai'),
('Pooja K','pooja.k@example.com','9000000037','Vile Parle, Mumbai'),
('Sahil N','sahil.n@example.com','9000000038','Andheri West, Mumbai'),
('Gauri P','gauri.p@example.com','9000000039','Kurla West, Mumbai'),
('Riddhi S','riddhi.s@example.com','9000000040','Dadar West, Mumbai');

-- Staff (60 staff - assign across 40 restaurants)
INSERT INTO Staff (restaurant_id, name, role, phone, salary, hire_date) VALUES
(1,'Vikas Singh','Manager','9234000001',45000.00,'2023-01-15'),
(1,'Anjali Desai','Chef','9234000002',35000.00,'2023-02-20'),
(1,'Ravi Mehta','Waiter','9234000003',20000.00,'2023-03-10'),
(2,'Kavita Joshi','Manager','9234000004',48000.00,'2022-11-01'),
(2,'Sandeep Rao','Chef','9234000005',38000.00,'2023-01-05'),
(3,'Pradeep Kumar','Manager','9234000006',50000.00,'2023-01-10'),
(3,'Shalini Nair','Chef','9234000007',40000.00,'2023-02-15'),
(4,'Manoj Tiwari','Chef','9234000008',42000.00,'2023-03-01'),
(4,'Geeta Rani','Waiter','9234000009',22000.00,'2023-04-10'),
(5,'Ramesh Babu','Manager','9234000010',46000.00,'2023-01-20'),
(5,'Lakshmi Devi','Chef','9234000011',36000.00,'2023-02-25'),
(6,'Chen Wei','Chef','9234000012',39000.00,'2023-03-05'),
(6,'Priya Malik','Waiter','9234000013',21000.00,'2023-04-15'),
(7,'Marco Rossi','Chef','9234000014',55000.00,'2023-01-25'),
(7,'Sofia D''Angelo','Manager','9234000015',52000.00,'2023-02-10'),
(8,'Ahmed Khan','Chef','9234000016',44000.00,'2023-03-15'),
(9,'Neha Kapoor','Manager','9234000017',47000.00,'2023-01-30'),
(10,'Sunil Pawar','Chef','9234000018',37000.00,'2023-02-20'),
(11,'Harpreet Singh','Chef','9234000019',43000.00,'2023-03-10'),
(12,'Yuki Tanaka','Chef','9234000020',58000.00,'2023-01-15'),
(13,'Giovanni Bianchi','Chef','9234000021',41000.00,'2023-02-28'),
(14,'Faisal Malik','Chef','9234000022',45000.00,'2023-03-20'),
(15,'Reena Patel','Manager','9234000023',49000.00,'2023-01-12'),
(16,'Ritu Sharma','Cashier','9234000024',25000.00,'2023-04-01'),
(17,'Amit Bhatt','Waiter','9234000025',20000.00,'2023-04-05'),
(18,'Sonal Iyer','Chef','9234000026',37000.00,'2023-03-18'),
(19,'Kiran Joshi','Manager','9234000027',45000.00,'2023-02-11'),
(20,'Deepa N','Chef','9234000028',36000.00,'2023-05-01'),
(21,'Rohit Sharma','Chef','9234000029',38000.00,'2023-02-20'),
(22,'Minal Patil','Manager','9234000030',47000.00,'2023-03-22'),
(23,'Ajay Rao','Chef','9234000031',35000.00,'2023-01-18'),
(24,'Sushma Deshpande','Waiter','9234000032',21000.00,'2023-04-12'),
(25,'Vandana Kulkarni','Chef','9234000033',39000.00,'2023-02-27'),
(26,'Manish K','Manager','9234000034',50000.00,'2023-01-05'),
(27,'Nandini S','Chef','9234000035',33000.00,'2023-03-03'),
(28,'Rakesh P','Waiter','9234000036',20000.00,'2023-04-08'),
(29,'Pooja R','Cashier','9234000037',24000.00,'2023-03-30'),
(30,'Bhushan T','Chef','9234000038',41000.00,'2023-02-14'),
(31,'Gita M','Manager','9234000039',46000.00,'2023-01-23'),
(32,'Vijay L','Chef','9234000040',42000.00,'2023-03-09'),
(33,'Sunita R','Waiter','9234000041',21000.00,'2023-04-02'),
(34,'Nikhil D','Chef','9234000042',43000.00,'2023-02-02'),
(35,'Rupal V','Manager','9234000043',48000.00,'2023-01-28'),
(36,'Harini S','Chef','9234000044',37000.00,'2023-05-10'),
(37,'Kavya P','Waiter','9234000045',20000.00,'2023-04-18'),
(38,'Maya N','Chef','9234000046',40000.00,'2023-03-12'),
(39,'Asha K','Manager','9234000047',47000.00,'2023-02-08'),
(40,'Rohit D','Chef','9234000048',39000.00,'2023-01-29'),
(41,'Siddharth P','Waiter','9234000049',21000.00,'2023-04-11'),
(42,'Neeta G','Chef','9234000050',36000.00,'2023-03-21'),
(43,'Rahul B','Manager','9234000051',49000.00,'2023-01-09'),
(44,'Priti C','Chef','9234000052',35000.00,'2023-02-16'),
(45,'Anup S','Waiter','9234000053',20000.00,'2023-03-27'),
(46,'Rhea M','Chef','9234000054',42000.00,'2023-04-03'),
(47,'Ketan H','Manager','9234000055',46500.00,'2023-02-05'),
(48,'Ila T','Chef','9234000056',35500.00,'2023-01-31'),
(49,'Tanya V','Waiter','9234000057',20500.00,'2023-04-06'),
(50,'Sameer Q','Chef','9234000058',41000.00,'2023-03-01'),
(51,'Rina Z','Manager','9234000059',49500.00,'2023-01-20'),
(52,'Kamal N','Chef','9234000060',37500.00,'2023-02-22');

-- Suppliers (40 suppliers)
INSERT INTO Supplier (name, contact_person, phone, email, address) VALUES
('Fresh Farm Produce','Rajesh Kumar','9345000001','rajesh@freshfarm.com','Market Yard, Pune'),
('Daily Dairy Suppliers','Sunita Patil','9345000002','sunita@dailydairy.com','Thane West, Mumbai'),
('Spice World','Arun Nair','9345000003','arun@spiceworld.com','Crawford Market, Mumbai'),
('Grain House','Ramesh Gupta','9345000004','ramesh@grainhouse.com','Dadar, Mumbai'),
('Organic Greens','Sanjay More','9345000005','sanjay@organicgreens.com','Navi Mumbai'),
('Bakery Supplies Co.','Prakash Jain','9345000006','prakash@bakerysupplies.com','Bandra, Mumbai'),
('Beverage Solutions','Neeta Shah','9345000007','neeta@beverage.com','Andheri, Mumbai'),
('Herb & Leaf','Vikram Rao','9345000008','vikram@herbandleaf.com','Pune Market, Pune'),
('Oil Traders','Mehul Shah','9345000009','mehul@oiltraders.com','Fort, Mumbai'),
('Cocoa & Sweets','Priya Joshi','9345000010','priya@cocoa.com','Lower Parel, Mumbai'),
('Rice Depot','Ramesh Nair','9345000011','ramesh@ricedepot.com','Thane, Mumbai'),
('Lentil Suppliers','Ketan Varma','9345000012','ketan@lentils.com','Dadar Market'),
('Tea Leaf Co.','Asha Desai','9345000013','asha@tealeaf.com','Colaba, Mumbai'),
('Coffee Kernels','Vikram Patil','9345000014','vikram@coffeekernels.com','Worli, Mumbai'),
('Fresh Vegetables Inc','Rohit Mehra','9345000015','rohit@freshveg.com','Pune Central Market'),
('Masala Depot','Aruna G','9345000016','aruna@masaladepot.com','Crawford Market'),
('Dairy Fresh','Sunil K','9345000017','sunil@dairyfresh.com','Pune Dairy Market'),
('Pulses & Co','Anil B','9345000018','anil@pulsesco.com','Pune'),
('Sugar Central','Hemant J','9345000019','hemant@sugarcentral.com','Vile Parle'),
('Salt & Spices','Rita D','9345000020','rita@saltspice.com','Bandra'),
('Eggless Bakery Supplies','Nilesh K','9345000021','nilesh@egglessbakery.com','Andheri'),
('Green Oil Mills','Alok P','9345000022','alok@greenoil.com','Goregaon'),
('Yeast Suppliers','Radhika M','9345000023','radhika@yeastsup.com','Thane West'),
('Saffron Traders','Kumar S','9345000024','kumar@saffrontraders.com','Fort'),
('Coconut Traders','Pooja M','9345000025','pooja@coconut.com','Vasai'),
('Paneer Makers','Vivek R','9345000026','vivek@paneermakers.com','Wakad'),
('Pickle House','Gautam L','9345000027','gautam@pickles.com','Camp'),
('Snack Ingredients','Ritu H','9345000028','ritu@snacking.com','Baner'),
('Oil & Ghee Hub','Suresh A','9345000029','suresh@oilandghee.com','Kothrud'),
('Cheese Suppliers','Nandita P','9345000030','nandita@cheesesup.com','Pimpri'),
('Basmati Traders','Sameer K','9345000031','sameer@basmati.com','LBS Marg'),
('Herbal Spices','Mohan R','9345000032','mohan@herbalspices.com','Crawford'),
('Juice Concentrates','Ankita S','9345000033','ankita@juiceco.com','Lower Parel'),
('Cereal Hub','Ramesh T','9345000034','ramesh@cerealhub.com','Navi Mumbai'),
('Tiffin Supplies','Kavita L','9345000035','kavita@tiffinsup.com','Goregaon'),
('Kadhi Mix Suppliers','Hiren V','9345000036','hiren@kadhimix.com','Thane'),
('Dry Fruits Co','Bhavesh D','9345000037','bhavesh@dryfruits.com','Dadar'),
('Sweets Essentials','Preeti N','9345000038','preeti@sweets.com','Colaba'),
('Veg Oil Traders','Rohan B','9345000039','rohan@vegoil.com','Worli'),
('Saltworks','Anuj M','9345000040','anuj@saltworks.com','Parel');

-- Inventory (80+ items across restaurants and suppliers) - all veg
INSERT INTO Inventory (restaurant_id, supplier_id, item_name, quantity, unit, reorder_level, last_restocked) VALUES
(1,1,'Tomatoes',120,'kg',20,'2025-10-28'),
(1,1,'Onions',100,'kg',20,'2025-10-28'),
(1,2,'Milk',80,'liters',20,'2025-10-29'),
(1,16,'Turmeric Powder',15,'kg',5,'2025-10-25'),
(2,15,'Rice',200,'kg',50,'2025-10-27'),
(2,11,'Basmati Rice',150,'kg',40,'2025-10-27'),
(3,14,'Coffee Beans',60,'kg',15,'2025-10-25'),
(3,9,'Olive Oil',50,'liters',10,'2025-10-26'),
(4,1,'Potatoes',180,'kg',30,'2025-10-28'),
(4,12,'Lentils',120,'kg',30,'2025-10-27'),
(5,20,'Sugar',90,'kg',20,'2025-10-26'),
(5,6,'Flour',160,'kg',40,'2025-10-26'),
(6,3,'Turmeric Powder',20,'kg',5,'2025-10-25'),
(6,17,'Yogurt',100,'liters',25,'2025-10-29'),
(7,23,'Yeast',25,'kg',5,'2025-10-26'),
(7,22,'Olive Oil',60,'liters',10,'2025-10-26'),
(8,18,'Pulses Mix',150,'kg',30,'2025-10-27'),
(8,13,'Tea Leaves',40,'kg',8,'2025-10-25'),
(9,4,'Coriander Powder',30,'kg',8,'2025-10-25'),
(9,5,'Green Vegetables Pack',200,'kg',50,'2025-10-28'),
(10,7,'Juice Concentrate',50,'liters',10,'2025-10-26'),
(10,10,'Cocoa Powder',40,'kg',8,'2025-10-26'),
(11,21,'Bread Dough',180,'kg',30,'2025-10-26'),
(11,30,'Cheese Blocks',80,'kg',15,'2025-10-29'),
(12,24,'Saffron (g)',1,'kg',0.2,'2025-10-25'),
(12,2,'Paneer',60,'kg',12,'2025-10-29'),
(13,8,'Herbs Mix',40,'kg',8,'2025-10-25'),
(13,26,'Pickles',120,'kg',20,'2025-10-27'),
(14,31,'Basmati Premium',120,'kg',30,'2025-10-27'),
(14,11,'Chickpeas',140,'kg',30,'2025-10-27'),
(15,6,'Sugar Fine',100,'kg',25,'2025-10-26'),
(15,33,'Juice Concentrate',30,'liters',8,'2025-10-26'),
(16,1,'Cabbage',90,'kg',20,'2025-10-28'),
(16,1,'Carrots',88,'kg',18,'2025-10-28'),
(17,9,'Olive Oil Large',40,'liters',8,'2025-10-26'),
(17,6,'Bakery Flour',120,'kg',30,'2025-10-26'),
(18,4,'Garam Masala',25,'kg',5,'2025-10-25'),
(18,11,'Rice Premium',100,'kg',25,'2025-10-27'),
(19,16,'Tiffin Mixes',110,'kg',30,'2025-10-27'),
(19,7,'Beverage Syrup',60,'liters',12,'2025-10-26'),
(20,19,'Salt Pack',200,'kg',40,'2025-10-26'),
(21,1,'Spinach',80,'kg',15,'2025-10-28'),
(21,3,'Red Chili Powder',40,'kg',8,'2025-10-25'),
(22,5,'Organic Veg Box',120,'kg',30,'2025-10-28'),
(22,15,'Pan Spray',30,'liters',8,'2025-10-26'),
(23,2,'Milk Pack',140,'liters',30,'2025-10-29'),
(23,27,'Snack Ingredients',60,'kg',12,'2025-10-27'),
(24,34,'Cereal Mix',80,'kg',15,'2025-10-27'),
(24,35,'Tiffin Supplies',100,'kg',20,'2025-10-27'),
(25,36,'Kadhi Mix',40,'kg',8,'2025-10-26'),
(25,37,'Dry Fruits',50,'kg',10,'2025-10-26'),
(26,38,'Sweets Essentials',70,'kg',15,'2025-10-26'),
(26,39,'Veg Oil',90,'liters',20,'2025-10-26'),
(27,40,'Saltworks Salt',200,'kg',40,'2025-10-26'),
(27,1,'Coriander Leaves',60,'kg',12,'2025-10-28'),
(28,2,'Curd',80,'liters',20,'2025-10-29'),
(28,3,'Mixed Spices',40,'kg',10,'2025-10-25'),
(29,4,'Chana',120,'kg',30,'2025-10-27'),
(29,5,'Fresh Veg Box',140,'kg',30,'2025-10-28'),
(30,6,'Maida',150,'kg',35,'2025-10-26'),
(30,7,'Beverage Base',60,'liters',12,'2025-10-26'),
(31,8,'Dried Herbs',50,'kg',10,'2025-10-25'),
(31,9,'Ghee',40,'liters',10,'2025-10-26'),
(32,10,'Dark Cocoa',30,'kg',6,'2025-10-26'),
(32,11,'Moong Dal',80,'kg',20,'2025-10-27'),
(33,12,'Black Pepper',25,'kg',6,'2025-10-25'),
(33,13,'Tea Special',45,'kg',10,'2025-10-25'),
(34,14,'Coffee Blend',50,'kg',12,'2025-10-25'),
(34,15,'Baking Salt',60,'kg',12,'2025-10-26'),
(35,16,'Sattu',75,'kg',18,'2025-10-27'),
(35,17,'Paneer Cubes',30,'kg',8,'2025-10-29'),
(36,18,'Ragi Flour',100,'kg',20,'2025-10-27'),
(36,19,'Sugar Fine',80,'kg',20,'2025-10-26'),
(37,20,'Salt Bulk',150,'kg',35,'2025-10-26'),
(37,21,'Eggless Cake Mix',40,'kg',8,'2025-10-26'),
(38,22,'Olive Oil Extra',35,'liters',8,'2025-10-26'),
(38,23,'Active Yeast',20,'kg',5,'2025-10-26'),
(39,24,'Premium Saffron',0.3,'kg',0.1,'2025-10-25'),
(39,25,'Coconut Milk',60,'liters',12,'2025-10-26'),
(40,26,'Fresh Paneer',50,'kg',10,'2025-10-29'),
(40,27,'Pickle Varieties',80,'kg',15,'2025-10-27');

-- Menu Items (120+ veg menu items across 40 restaurants)
INSERT INTO Menu_Item (restaurant_id, name, description, category, price, availability) VALUES
-- Restaurant 1
(1,'Paneer Butter Masala','Creamy tomato based paneer curry','Main Course',260.00,TRUE),
(1,'Dal Makhani','Slow cooked black lentils','Main Course',180.00,TRUE),
(1,'Jeera Rice','Fragrant cumin rice','Side',90.00,TRUE),
(1,'Gulab Jamun','Sweet milk dumplings','Dessert',110.00,TRUE),
(1,'Naan','Soft Indian flatbread','Side',40.00,TRUE),
(2,'Masala Dosa','Crispy dosa with potato masala','Main Course',120.00,TRUE),
(2,'Sambar','Lentil stew with vegetables','Side',80.00,TRUE),
(2,'Idli','Steamed rice cakes','Appetizer',70.00,TRUE),
(2,'Filter Coffee','South Indian Coffee','Beverage',60.00,TRUE),
(3,'Veg Biryani','Aromatic vegetable biryani','Main Course',210.00,TRUE),
(3,'Raita','Yogurt side with cucumber','Side',60.00,TRUE),
(3,'Mirchi Ka Salan','Spicy chili curry','Side',120.00,TRUE),
(4,'Chole Bhature','Spicy chickpeas with fried bread','Main Course',160.00,TRUE),
(4,'Pav Bhaji','Mixed veg masala with buns','Main Course',140.00,TRUE),
(4,'Vada Pav','Spicy potato fritter in bun','Appetizer',50.00,TRUE),
(5,'Palak Paneer','Spinach and cottage cheese','Main Course',230.00,TRUE),
(5,'Tandoori Roti','Clay oven bread','Side',30.00,TRUE),
(5,'Kesar Pista Kulfi','Saffron-pistachio ice cream','Dessert',150.00,TRUE),
(6,'Hakka Noodles','Stir fried veg noodles','Main Course',180.00,TRUE),
(6,'Spring Rolls','Crispy veg rolls','Appetizer',150.00,TRUE),
(6,'Veg Manchurian','Veg balls in tangy sauce','Main Course',170.00,TRUE),
(7,'Margherita Pizza','Cheesy tomato pizza','Main Course',320.00,TRUE),
(7,'Pasta Arrabiata','Spicy tomato pasta','Main Course',280.00,TRUE),
(7,'Garlic Bread','Bread with garlic butter','Side',120.00,TRUE),
(8,'Sattvik Thali','Assorted pure veg thali','Main Course',300.00,TRUE),
(8,'Roti','Whole wheat flatbread','Side',25.00,TRUE),
(8,'Kesari Bhaat','Sweet saffron rice','Dessert',110.00,TRUE),
(9,'Paneer Tikka','Grilled paneer skewers','Appetizer',240.00,TRUE),
(9,'Veg Seekh Kebab','Veg kebab with spices','Appetizer',220.00,TRUE),
(9,'Naan Basket','Assorted naans','Side',120.00,TRUE),
(10,'Puri Bhaji','Fried bread with potato curry','Main Course',110.00,TRUE),
(10,'Misal Pav','Spicy sprout curry','Main Course',150.00,TRUE),
(10,'Sheera','Semolina sweet dish','Dessert',90.00,TRUE),
(11,'Dhokla','Steamed gram flour cake','Appetizer',80.00,TRUE),
(11,'Thepla','Gujarati flatbread','Side',70.00,TRUE),
(11,'Undhiyu','Mixed veg delicacy','Main Course',220.00,TRUE),
(12,'Veg Korma','Mixed veg in creamy sauce','Main Course',210.00,TRUE),
(12,'Parotta','Layered flatbread','Side',50.00,TRUE),
(12,'Payasam','Sweet milk pudding','Dessert',100.00,TRUE),
(13,'Veg Fried Rice','Chinese style fried rice','Main Course',180.00,TRUE),
(13,'Manchurian Dry','Veg manchurian dry','Appetizer',170.00,TRUE),
(13,'Hot & Sour Soup','Tangy veg soup','Side',120.00,TRUE),
(14,'Rava Uttapam','Thick rice pancake','Main Course',140.00,TRUE),
(14,'Coconut Chutney','Coconut and spice chutney','Side',30.00,TRUE),
(14,'Laddu','Sweet gram ball','Dessert',80.00,TRUE),
(15,'Veggie Supreme Pizza','Loaded veg pizza','Main Course',360.00,TRUE),
(15,'Tiramisu (Eggless)','Coffee flavoured dessert','Dessert',200.00,TRUE),
(15,'Caprese Salad','Tomato, basil and cheese','Appetizer',180.00,TRUE),
(16,'Ragda Patties','Spiced white peas on potato patties','Appetizer',140.00,TRUE),
(16,'Pattice Pav','Potato cakes with chutney','Side',90.00,TRUE),
(16,'Mango Lassi','Mango yogurt drink','Beverage',110.00,TRUE),
(17,'Kadhi Pakora','Gram flour dumplings in yogurt gravy','Main Course',160.00,TRUE),
(17,'Steamed Rice','Plain steamed rice','Side',60.00,TRUE),
(17,'Gajar Halwa','Carrot sweet pudding','Dessert',120.00,TRUE),
(18,'Kathi Roll Veg','Wrap with spiced veg filling','Main Course',150.00,TRUE),
(18,'French Fries','Crispy potato fries','Side',90.00,TRUE),
(18,'Cold Coffee','Chilled coffee','Beverage',140.00,TRUE),
(19,'Methi Malai Mutter','Fenugreek peas in creamy sauce','Main Course',210.00,TRUE),
(19,'Bhatura','Fried bread','Side',50.00,TRUE),
(19,'Rasmalai','Cheese dumplings in sweet milk','Dessert',130.00,TRUE),
(20,'Veg Sizzler','Grilled veg sizzler with sauces','Main Course',300.00,TRUE),
(20,'Mixed Salad','Fresh garden salad','Appetizer',120.00,TRUE),
(20,'Cold Pressed Juice','Seasonal juice','Beverage',140.00,TRUE),
-- Restaurants 21-40 (add items for each)
(21,'Paneer Lababdar','Creamy onion tomato gravy paneer','Main Course',270.00,TRUE),
(21,'Aloo Gobi','Potato and cauliflower','Main Course',150.00,TRUE),
(21,'Phulka','Whole wheat roti','Side',20.00,TRUE),
(22,'Gujarati Thali','Traditional Gujarati thali','Main Course',260.00,TRUE),
(22,'Fafda','Gram flour snack','Appetizer',80.00,TRUE),
(22,'Shrikhand','Sweet yogurt dessert','Dessert',120.00,TRUE),
(23,'Vegetable Kootu','South Indian vegetable stew','Main Course',180.00,TRUE),
(23,'Rasam','Tangy south indian soup','Side',50.00,TRUE),
(24,'Methi Thepla','Fenugreek flatbread','Side',70.00,TRUE),
(24,'Dal Tadka','Yellow lentil with tempering','Main Course',140.00,TRUE),
(25,'Veg Kolhapuri','Spicy Maharashtrian veg curry','Main Course',220.00,TRUE),
(25,'Bhakri','Millet flatbread','Side',45.00,TRUE),
(26,'Malai Kofta','Cottage cheese dumplings in gravy','Main Course',250.00,TRUE),
(26,'Noodles','Veg noodles','Main Course',160.00,TRUE),
(27,'Masala Pav','Spiced pav','Appetizer',60.00,TRUE),
(27,'Schezwan Fried Rice','Spicy fried rice','Main Course',190.00,TRUE),
(28,'Veg Spring Roll','Veg rolls','Appetizer',140.00,TRUE),
(28,'Sweet Lassi','Yogurt based drink','Beverage',90.00,TRUE),
(29,'Paneer Lab','Paneer in special sauce','Main Course',260.00,TRUE),
(29,'Vegetable Cutlet','Spiced veg cutlet','Appetizer',110.00,TRUE),
(30,'Corn Chaat','Sweet corn chaat','Appetizer',90.00,TRUE),
(30,'Veg Stew','Mixed veg stew with bread','Main Course',170.00,TRUE),
(31,'Mango Kulfi','Mango ice cream','Dessert',150.00,TRUE),
(31,'Pav Bhaji Slider','Mini pav bhaji','Appetizer',120.00,TRUE),
(32,'Cheese Chilly','Cheese cubes in chilli sauce','Appetizer',200.00,TRUE),
(32,'Brownie (Eggless)','Chocolate brownie','Dessert',140.00,TRUE),
(33,'Rogan Josh Veg','Spiced veg curry','Main Course',230.00,TRUE),
(33,'Saffron Rice','Aromatic saffron rice','Side',100.00,TRUE),
(34,'Palak Pasta','Spinach pasta','Main Course',250.00,TRUE),
(34,'Bruschetta','Toasted bread with tomato','Appetizer',150.00,TRUE),
(35,'Gujarati Kadhi','Sweet and tangy kadhi','Side',90.00,TRUE),
(35,'Sev Usal','Spicy sprouts curry','Main Course',160.00,TRUE),
(36,'Rava Dosa','Crispy dosa variant','Main Course',130.00,TRUE),
(36,'Coconut Chutney','Coconut dip','Side',30.00,TRUE),
(37,'Stuffed Paratha','Aloo or paneer stuffing','Main Course',110.00,TRUE),
(37,'Butter Naan','Soft naan with butter','Side',45.00,TRUE),
(38,'Veg Pakora','Assorted veg fritters','Appetizer',90.00,TRUE),
(38,'Jalebi','Sweet fried spiral','Dessert',80.00,TRUE),
(39,'Rajma Chawal','Kidney beans with rice','Main Course',160.00,TRUE),
(39,'Boondi Raita','Yogurt with boondi','Side',60.00,TRUE),
(40,'Methi Gota','Gujarati fenugreek fritter','Appetizer',100.00,TRUE),
(40,'Puran Poli','Sweet stuffed flatbread','Dessert',120.00,TRUE);

-- Delivery Agents (40 agents)
INSERT INTO Delivery_Agent (name, phone, vehicle_type, availability, rating) VALUES
('Suresh Yadav','9456000001','Bike',TRUE,4.6),
('Deepak Sharma','9456000002','Bike',TRUE,4.4),
('Manoj Singh','9456000003','Scooter',TRUE,4.8),
('Rakesh Kumar','9456000004','Bike',TRUE,4.5),
('Vijay Pandey','9456000005','Bike',TRUE,4.7),
('Ajay Verma','9456000006','Scooter',TRUE,4.3),
('Dinesh Patil','9456000007','Bike',TRUE,4.6),
('Rajesh Gupta','9456000008','Bike',TRUE,4.8),
('Sunil Jadhav','9456000009','Scooter',TRUE,4.4),
('Prakash More','9456000010','Bike',TRUE,4.5),
('Nitin Rao','9456000011','Bike',TRUE,4.2),
('Karan S','9456000012','Scooter',TRUE,4.1),
('Vivek P','9456000013','Bike',TRUE,4.3),
('Rohit B','9456000014','Bike',TRUE,4.0),
('Sahil K','9456000015','Scooter',TRUE,4.2),
('Ankit D','9456000016','Bike',TRUE,4.5),
('Mohan L','9456000017','Bike',TRUE,4.6),
('Girish N','9456000018','Scooter',TRUE,4.4),
('Kunal T','9456000019','Bike',TRUE,4.3),
('Hitesh R','9456000020','Bike',TRUE,4.1),
('Sandeep M','9456000021','Scooter',TRUE,4.5),
('Rajat V','9456000022','Bike',TRUE,4.7),
('Aman P','9456000023','Bike',TRUE,4.0),
('Irfan Q','9456000024','Scooter',TRUE,4.3),
('Pranav S','9456000025','Bike',TRUE,4.6),
('Mahesh K','9456000026','Bike',TRUE,4.2),
('Harish C','9456000027','Scooter',TRUE,4.1),
('Suresh D','9456000028','Bike',TRUE,4.4),
('Bharat Y','9456000029','Bike',TRUE,4.5),
('Venkatesh R','9456000030','Scooter',TRUE,4.6),
('Lokesh J','9456000031','Bike',TRUE,4.3),
('Prithvi N','9456000032','Scooter',TRUE,4.0),
('Dilip S','9456000033','Bike',TRUE,4.2),
('Abhay T','9456000034','Bike',TRUE,4.1),
('Yusuf K','9456000035','Scooter',TRUE,4.5),
('Shyam P','9456000036','Bike',TRUE,4.4),
('Kishore M','9456000037','Scooter',TRUE,4.2),
('Sanjay L','9456000038','Bike',TRUE,4.3),
('Ramesh J','9456000039','Bike',TRUE,4.6),
('Pradeep H','9456000040','Scooter',TRUE,4.1);

-- Orders (60 orders) - ensure customers 1..40 and restaurants 1..40 referenced
INSERT INTO Orders (customer_id, restaurant_id, order_type, status, total_amount) VALUES
(1,1,'delivery','delivered',520.00),
(2,1,'dine-in','completed',300.00),
(3,2,'delivery','preparing',450.00),
(4,3,'takeaway','ready',380.00),
(5,4,'dine-in','completed',420.00),
(6,5,'delivery','delivered',560.00),
(7,6,'dine-in','completed',480.00),
(8,7,'takeaway','ready',360.00),
(9,8,'delivery','preparing',610.00),
(10,9,'dine-in','completed',420.00),
(11,10,'delivery','delivered',350.00),
(12,11,'takeaway','ready',300.00),
(13,12,'dine-in','completed',540.00),
(14,13,'delivery','preparing',410.00),
(15,14,'dine-in','completed',240.00),
(16,15,'delivery','delivered',620.00),
(17,16,'takeaway','ready',290.00),
(18,17,'delivery','preparing',430.00),
(19,18,'dine-in','completed',380.00),
(20,19,'takeaway','ready',360.00),
(21,20,'delivery','delivered',520.00),
(22,21,'dine-in','completed',260.00),
(23,22,'delivery','preparing',470.00),
(24,23,'takeaway','ready',300.00),
(25,24,'dine-in','completed',390.00),
(26,25,'delivery','delivered',450.00),
(27,26,'dine-in','completed',510.00),
(28,27,'takeaway','ready',230.00),
(29,28,'delivery','preparing',340.00),
(30,29,'dine-in','completed',600.00),
(31,30,'delivery','delivered',280.00),
(32,31,'takeaway','ready',220.00),
(33,32,'dine-in','completed',380.00),
(34,33,'delivery','delivered',430.00),
(35,34,'dine-in','completed',490.00),
(36,35,'takeaway','ready',210.00),
(37,36,'delivery','in_transit',540.00),
(38,37,'dine-in','completed',360.00),
(39,38,'delivery','delivered',300.00),
(40,39,'takeaway','ready',270.00),
(1,40,'delivery','preparing',320.00),
(2,3,'dine-in','completed',280.00),
(3,4,'delivery','delivered',450.00),
(4,5,'takeaway','ready',190.00),
(5,6,'dine-in','completed',330.00),
(6,7,'delivery','delivered',410.00),
(7,8,'takeaway','ready',240.00),
(8,9,'dine-in','completed',370.00),
(9,10,'delivery','delivered',290.00),
(10,11,'takeaway','ready',260.00),
(11,12,'dine-in','completed',310.00),
(12,13,'delivery','delivered',450.00),
(13,14,'takeaway','ready',190.00),
(14,15,'dine-in','completed',220.00),
(15,16,'delivery','delivered',400.00),
(16,17,'takeaway','ready',180.00),
(17,18,'dine-in','completed',360.00),
(18,19,'delivery','delivered',420.00);

-- Order Items (120+ items) -- reference menu items inserted above; using item ids will be sequential as inserted
-- To ensure item_ids are valid: we inserted 120+ items above; item_id sequence starts at 1
-- We'll create 120 order_item rows referencing existing orders and items.
INSERT INTO Order_Item (order_id, item_id, quantity, price) VALUES
(1,1,1,260.00),
(1,3,1,90.00),
(2,2,2,120.00),
(3,6,1,120.00),
(3,7,1,80.00),
(4,10,1,210.00),
(4,11,1,60.00),
(5,13,2,140.00),
(6,15,1,230.00),
(6,16,1,30.00),
(7,18,1,180.00),
(7,19,2,150.00),
(8,21,1,320.00),
(8,22,1,280.00),
(9,24,1,300.00),
(9,25,1,90.00),
(10,29,1,240.00),
(10,30,1,220.00),
(11,31,2,120.00),
(12,33,1,140.00),
(13,36,1,300.00),
(13,37,1,320.00),
(14,40,1,170.00),
(15,41,1,140.00),
(16,43,1,210.00),
(16,44,1,110.00),
(17,45,2,220.00),
(18,48,1,150.00),
(19,50,1,210.00),
(20,52,1,120.00),
(21,54,1,300.00),
(21,55,1,120.00),
(22,56,1,260.00),
(23,58,1,260.00),
(24,60,2,140.00),
(25,62,1,220.00),
(26,64,1,250.00),
(27,66,1,210.00),
(28,68,1,60.00),
(29,70,1,140.00),
(30,72,2,300.00),
(31,74,1,120.00),
(32,76,1,90.00),
(33,78,1,200.00),
(34,80,1,150.00),
(35,82,1,250.00),
(36,84,1,130.00),
(37,86,1,300.00),
(38,88,1,120.00),
(39,90,1,80.00),
(40,92,1,120.00),
(41,94,1,260.00),
(42,96,1,140.00),
(43,98,1,180.00),
(44,100,1,200.00),
(45,102,1,160.00),
(46,104,1,140.00),
(47,106,1,120.00),
(48,108,1,150.00),
(49,110,1,100.00),
(50,112,1,140.00),
(51,114,1,200.00),
(52,116,1,120.00),
(53,118,1,260.00),
(54,120,1,160.00),
(55,2,1,120.00),
(56,4,1,210.00),
(57,6,1,120.00),
(58,8,1,90.00),
(59,10,1,210.00),
(60,12,1,60.00),
(1,5,1,40.00),
(2,9,1,70.00),
(3,14,1,120.00),
(4,17,1,260.00),
(5,20,1,30.00),
(6,23,1,200.00),
(7,26,1,120.00),
(8,28,2,150.00),
(9,32,1,110.00),
(10,34,1,250.00),
(11,35,1,170.00),
(12,38,1,140.00),
(13,39,1,150.00),
(14,42,1,90.00),
(15,46,1,360.00),
(16,49,1,120.00),
(17,51,1,220.00),
(18,53,1,120.00),
(19,57,1,140.00),
(20,59,1,180.00),
(21,61,1,300.00),
(22,63,1,80.00),
(23,65,1,190.00),
(24,67,1,70.00),
(25,69,1,150.00),
(26,71,1,190.00),
(27,73,1,120.00),
(28,75,1,160.00),
(29,77,1,90.00),
(30,79,1,140.00),
(31,81,1,110.00),
(32,83,1,250.00),
(33,85,1,130.00),
(34,87,1,170.00),
(35,89,1,160.00),
(36,91,1,140.00),
(37,93,1,120.00),
(38,95,1,150.00),
(39,97,1,100.00),
(40,99,1,140.00),
(41,101,1,200.00),
(42,103,1,120.00),
(43,105,1,260.00),
(44,107,1,160.00),
(45,109,1,120.00),
(46,111,1,140.00),
(47,113,1,200.00),
(48,115,1,120.00),
(49,117,1,180.00),
(50,119,1,120.00),
(51,1,1,260.00),
(52,3,1,90.00),
(53,5,1,40.00),
(54,7,1,170.00),
(55,11,1,60.00),
(56,13,1,210.00),
(57,15,1,230.00),
(58,16,1,30.00),
(59,18,1,180.00),
(60,20,1,120.00);

-- Payments (60+ payments) - match orders 1..60
INSERT INTO Payment (order_id, payment_method, amount, status) VALUES
(1,'upi',520.00,'completed'),
(2,'card',300.00,'completed'),
(3,'cash',450.00,'pending'),
(4,'upi',380.00,'completed'),
(5,'cash',420.00,'completed'),
(6,'card',560.00,'completed'),
(7,'upi',480.00,'completed'),
(8,'cash',360.00,'completed'),
(9,'upi',610.00,'pending'),
(10,'card',420.00,'completed'),
(11,'upi',350.00,'completed'),
(12,'cash',300.00,'completed'),
(13,'card',540.00,'completed'),
(14,'upi',410.00,'pending'),
(15,'cash',240.00,'completed'),
(16,'upi',620.00,'completed'),
(17,'cash',290.00,'completed'),
(18,'card',430.00,'completed'),
(19,'upi',380.00,'completed'),
(20,'cash',360.00,'completed'),
(21,'card',520.00,'completed'),
(22,'upi',260.00,'completed'),
(23,'cash',470.00,'pending'),
(24,'card',300.00,'completed'),
(25,'upi',390.00,'completed'),
(26,'cash',450.00,'completed'),
(27,'card',510.00,'completed'),
(28,'upi',230.00,'pending'),
(29,'cash',340.00,'completed'),
(30,'card',600.00,'completed'),
(31,'upi',280.00,'completed'),
(32,'cash',220.00,'completed'),
(33,'card',380.00,'completed'),
(34,'upi',430.00,'completed'),
(35,'cash',490.00,'completed'),
(36,'card',210.00,'completed'),
(37,'upi',540.00,'pending'),
(38,'cash',360.00,'completed'),
(39,'card',300.00,'completed'),
(40,'upi',270.00,'pending'),
(41,'cash',320.00,'completed'),
(42,'card',280.00,'completed'),
(43,'upi',450.00,'completed'),
(44,'cash',190.00,'completed'),
(45,'card',330.00,'completed'),
(46,'upi',410.00,'completed'),
(47,'cash',240.00,'completed'),
(48,'card',370.00,'completed'),
(49,'upi',290.00,'completed'),
(50,'cash',260.00,'completed'),
(51,'card',310.00,'completed'),
(52,'upi',450.00,'pending'),
(53,'cash',190.00,'completed'),
(54,'card',220.00,'completed'),
(55,'upi',360.00,'completed'),
(56,'cash',410.00,'completed'),
(57,'card',180.00,'completed'),
(58,'upi',360.00,'pending'),
(59,'cash',420.00,'completed'),
(60,'card',300.00,'completed');

-- Deliveries (40 deliveries) - agent_id 1..40 exist; order_id references existing orders
INSERT INTO Delivery (order_id, agent_id, pickup_time, delivery_time, delivery_address, status) VALUES
(1,1,'2025-11-01 19:30:00','2025-11-01 20:05:00','Flat 101, Shanti Nagar, Pune','delivered'),
(3,2,'2025-11-02 20:00:00',NULL,'House 12, Baner, Pune','picked_up'),
(6,4,'2025-11-02 21:00:00','2025-11-02 21:35:00','Building C, Hinjewadi, Pune','delivered'),
(9,5,'2025-11-03 19:45:00',NULL,'Flat 8, Colaba, Mumbai','in_transit'),
(11,8,'2025-11-03 20:30:00','2025-11-03 21:10:00','Tower 5, Linking Road, Mumbai','delivered'),
(14,1,'2025-11-04 19:00:00',NULL,'Apartment 3C, Fort, Mumbai','picked_up'),
(16,6,'2025-11-04 20:15:00','2025-11-04 20:50:00','Building C, Hinjewadi, Pune','delivered'),
(19,9,'2025-11-05 19:30:00',NULL,'House 45, Thane, Mumbai','in_transit'),
(21,10,'2025-11-05 18:40:00','2025-11-05 19:05:00','Tower 3, Goregaon, Mumbai','delivered'),
(23,11,'2025-11-05 19:00:00',NULL,'Hinjewadi Phase 1, Pune','picked_up'),
(26,12,'2025-11-06 12:30:00','2025-11-06 13:05:00','MG Road Residences, Pune','delivered'),
(27,13,'2025-11-06 13:45:00',NULL,'Sector 12, Navi Mumbai','picked_up'),
(29,14,'2025-11-06 18:20:00','2025-11-06 18:55:00','Baner Pashan Link Rd, Pune','delivered'),
(30,15,'2025-11-06 19:00:00',NULL,'Aundh, Pune','picked_up'),
(31,16,'2025-11-07 11:00:00','2025-11-07 11:40:00','Deccan Gymkhana, Pune','delivered'),
(33,17,'2025-11-07 12:20:00',NULL,'Wakad, Pune','picked_up'),
(34,18,'2025-11-07 13:25:00','2025-11-07 14:00:00','Camp, Pune','delivered'),
(36,19,'2025-11-07 18:10:00',NULL,'Sinhagad Rd, Pune','picked_up'),
(37,20,'2025-11-08 10:30:00','2025-11-08 11:05:00','Pune Station Area, Pune','delivered'),
(39,21,'2025-11-08 12:00:00',NULL,'Worli, Mumbai','picked_up'),
(41,22,'2025-11-08 13:45:00','2025-11-08 14:20:00','Vile Parle East, Mumbai','delivered'),
(43,23,'2025-11-08 15:10:00',NULL,'Bandra West, Mumbai','picked_up'),
(44,24,'2025-11-08 16:00:00','2025-11-08 16:45:00','Andheri West, Mumbai','delivered'),
(46,25,'2025-11-09 09:30:00',NULL,'Juhu, Mumbai','picked_up'),
(47,26,'2025-11-09 11:00:00','2025-11-09 11:35:00','Dadar, Mumbai','delivered'),
(48,27,'2025-11-09 12:15:00',NULL,'Powai, Mumbai','picked_up'),
(49,28,'2025-11-09 13:40:00','2025-11-09 14:10:00','Colaba, Mumbai','delivered'),
(50,29,'2025-11-09 14:50:00',NULL,'Fort, Mumbai','picked_up'),
(51,30,'2025-11-09 15:30:00','2025-11-09 16:00:00','Malad, Mumbai','delivered'),
(52,31,'2025-11-09 17:10:00',NULL,'Lower Parel, Mumbai','picked_up'),
(53,32,'2025-11-09 18:30:00','2025-11-09 19:05:00','Goregaon, Mumbai','delivered'),
(54,33,'2025-11-10 10:00:00',NULL,'Thane, Mumbai','picked_up'),
(55,34,'2025-11-10 11:15:00','2025-11-10 11:50:00','Worli, Mumbai','delivered'),
(56,35,'2025-11-10 12:00:00',NULL,'Kothrud West, Pune','picked_up'),
(57,36,'2025-11-10 12:45:00','2025-11-10 13:25:00','Pune Station Area, Pune','delivered'),
(58,37,'2025-11-10 14:20:00',NULL,'Shivaji Nagar, Pune','picked_up'),
(59,38,'2025-11-10 15:10:00','2025-11-10 15:50:00','Navi Mumbai, CBD','delivered'),
(60,39,'2025-11-10 16:30:00',NULL,'Khar West, Mumbai','picked_up');

-- Table Reservations (40 reservations)
INSERT INTO Table_Reservation (customer_id, restaurant_id, table_number, reservation_date, reservation_time, party_size, status) VALUES
(1,1,5,'2025-11-05','19:00:00',4,'confirmed'),
(2,2,3,'2025-11-06','20:00:00',2,'pending'),
(3,3,7,'2025-11-05','18:30:00',6,'confirmed'),
(4,4,2,'2025-11-07','19:30:00',4,'pending'),
(5,5,4,'2025-11-05','08:00:00',2,'confirmed'),
(6,7,8,'2025-11-06','20:30:00',5,'confirmed'),
(7,8,6,'2025-11-07','21:00:00',3,'pending'),
(8,10,1,'2025-11-05','12:00:00',4,'confirmed'),
(9,11,5,'2025-11-06','19:00:00',6,'confirmed'),
(10,12,3,'2025-11-07','20:00:00',2,'pending'),
(11,13,9,'2025-11-05','19:30:00',4,'confirmed'),
(12,14,7,'2025-11-06','20:30:00',5,'confirmed'),
(13,15,2,'2025-11-07','15:00:00',2,'pending'),
(14,1,10,'2025-11-08','18:00:00',8,'pending'),
(15,6,4,'2025-11-08','19:00:00',4,'pending'),
(16,16,12,'2025-11-09','13:00:00',3,'confirmed'),
(17,17,2,'2025-11-09','20:30:00',2,'confirmed'),
(18,18,5,'2025-11-10','19:30:00',4,'pending'),
(19,19,3,'2025-11-10','18:00:00',2,'confirmed'),
(20,20,6,'2025-11-11','20:00:00',5,'confirmed'),
(21,21,4,'2025-11-11','19:00:00',4,'pending'),
(22,22,7,'2025-11-12','18:30:00',3,'confirmed'),
(23,23,10,'2025-11-12','20:00:00',6,'confirmed'),
(24,24,1,'2025-11-13','12:30:00',2,'pending'),
(25,25,5,'2025-11-13','19:45:00',4,'confirmed'),
(26,26,8,'2025-11-14','20:15:00',5,'confirmed'),
(27,27,3,'2025-11-14','18:00:00',2,'pending'),
(28,28,9,'2025-11-15','20:00:00',8,'confirmed'),
(29,29,11,'2025-11-15','13:00:00',3,'pending'),
(30,30,2,'2025-11-16','19:30:00',4,'confirmed'),
(31,31,6,'2025-11-16','20:00:00',5,'pending'),
(32,32,4,'2025-11-17','12:00:00',2,'confirmed'),
(33,33,7,'2025-11-17','19:00:00',6,'confirmed'),
(34,34,10,'2025-11-18','20:30:00',8,'pending'),
(35,35,3,'2025-11-18','18:00:00',2,'confirmed'),
(36,36,5,'2025-11-19','19:15:00',4,'confirmed'),
(37,37,4,'2025-11-19','12:30:00',2,'pending'),
(38,38,6,'2025-11-20','20:00:00',6,'confirmed'),
(39,39,8,'2025-11-20','19:00:00',4,'pending'),
(40,40,9,'2025-11-21','18:00:00',5,'confirmed');

-- Useful Views (as in your original script)
CREATE VIEW order_details AS
SELECT 
    o.order_id,
    c.name AS customer_name,
    r.name AS restaurant_name,
    o.order_type,
    o.order_date,
    o.status,
    o.total_amount
FROM Orders o
JOIN Customer c ON o.customer_id = c.customer_id
JOIN Restaurant r ON o.restaurant_id = r.restaurant_id;

CREATE VIEW revenue_by_restaurant AS
SELECT 
    r.name AS restaurant_name,
    COUNT(o.order_id) AS total_orders,
    SUM(o.total_amount) AS total_revenue
FROM Restaurant r
LEFT JOIN Orders o ON r.restaurant_id = o.restaurant_id
WHERE o.status != 'cancelled'
GROUP BY r.restaurant_id, r.name;

COMMIT;
